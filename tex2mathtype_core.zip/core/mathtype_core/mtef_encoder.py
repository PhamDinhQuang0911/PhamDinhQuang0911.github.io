# -*- coding: utf-8 -*-
"""
mtef_encoder.py

Xây MTEF v5 (MathType Equation Native) tổng quát cho MỌI công thức
chứa cung tròn (overparen). Dùng font table từ Doc3.doc thật.

Các template MTEF được hỗ trợ:
  0x01 SQRT      0x08 OVERLINE    0x09 UNDERLINE
  0x0A WIDEHAT   0x0B FRAC        0x0D SUB
  0x0E SUP       0x0F SUBSUP      0x10 INTEGRAL
  0x12 SUM       0x13 LIMIT       0x17 BINOM
  0x1B OVERARROW 0x22 FROWN

CHAR embellishments: 0x03 vec, 0x06 hat, 0x07 tilde, 0x0A dot, 0x0B ddot

Usage:
    from .mtef_encoder import latex_to_mtef
    mtef_bytes = latex_to_mtef(r"\\widehat{ACB}=\\frac{1}{2}sd\\overparen{ABC}")
    # => MTEF v5 giống hệt Doc3.doc, 1 OLE duy nhất
"""

import re
import struct

# ──────────────────────────────────────────────
# FONT TABLE từ Doc3.doc (219 bytes)
# ──────────────────────────────────────────────
_DOC3_PREFIX_HEX = (
    "1c00000002007dc21c010000000000008838fa062ddf88000c003d06"
    "050100070844534d543700011357696e416c6c4261736963436f6465"
    "506167657300110554696d6573204e657720526f6d616e0011035379"
    "6d626f6c001105436f7572696572204e65770011044d542045787472"
    "6100120008212f458f442f4150f4100f475f4150f21f1e4150f4150f"
    "4100f445f425f48f425f4100f4100f435f4100f48f45f42a5f48f48f"
    "4100f4100f40f48f417f48f4100f412a5f445f45f45f45f45f410f0c"
    "0100010001020202020002000101010003000100040000"
)
_DOC3_PREFIX = bytes.fromhex(_DOC3_PREFIX_HEX)

# Font indices (từ Doc3.doc)
FONT_TIMES    = 0  # typeface 0x81
FONT_SYMBOL   = 1  # typeface 0x83
FONT_COURIER  = 2  # typeface 0x85
FONT_MTEXTRA  = 3  # typeface 0x96

# Typeface bytes
TF_TEXT    = 0x81  # font Times, text style
TF_VAR     = 0x83  # font Symbol, variable style  (dùng cho = + - và biến trong FROWN)
TF_MTEXTRA = 0x96  # font MT Extra

# Embellishment types
EMBELL_VEC  = 0x03
EMBELL_HAT  = 0x06
EMBELL_TILDE = 0x07
EMBELL_DOT  = 0x0A
EMBELL_DDOT = 0x0B
EMBELL_BAR  = 0x08

# Template types
T_SQRT      = 0x01
T_OVERLINE  = 0x08
T_UNDERLINE = 0x09
T_WIDEHAT   = 0x0A
T_FRAC      = 0x0B
T_SUB       = 0x0D
T_SUP       = 0x0E
T_SUBSUP    = 0x0F
T_INTEGRAL  = 0x10
T_SUM       = 0x12
T_LIMIT     = 0x13
T_BINOM     = 0x17
T_OVERARROW = 0x1B
T_FROWN     = 0x22

# ──────────────────────────────────────────────
# MTEF record builders
# ──────────────────────────────────────────────

def _line_start() -> bytes:
    """LINE_START: 0a 01 00 01 00"""
    return b'\x0a\x01\x00\x01\x00'

def _char(ch: str, tf: int = TF_TEXT, embell: int | None = None) -> bytes:
    """CHAR record: tag=02, opts, typeface, char, [embell_data], extra
    
    For Unicode > 255 (e.g. U+2322 FROWN): code is stored as lo, hi bytes.
    """
    code = ord(ch)
    if code > 255:
        # 2-byte character code: lo, hi
        lo = code & 0xFF
        hi = (code >> 8) & 0xFF
        if embell is not None:
            return bytes([0x02, 0x01, tf, lo, hi, embell, 0x00, 0x09, 0x00])
        else:
            return bytes([0x02, 0x00, tf, lo, hi])
    else:
        if embell is not None:
            # opts bit 0 = 1 (has embellishment)
            # 02 01 tf ch 00 ET 00 SS 00
            # ET = embell type, SS = embell slot
            return bytes([0x02, 0x01, tf, code, 0x00, embell, 0x00, 0x09, 0x00])
        else:
            return bytes([0x02, 0x00, tf, code, 0x00])

def _chars(s: str, tf: int = TF_TEXT) -> bytes:
    return b''.join(_char(c, tf) for c in s)

def _char_var(ch: str) -> bytes:
    """CHAR with Symbol font (cho toán tử = + - × ÷ ...)"""
    return _char(ch, TF_VAR)

def _tmpl_header(tmpl_type: int, slot_count: int = 1) -> bytes:
    """TMPL header: 03 00 TT 00 00 NN 00"""
    return bytes([0x03, 0x00, tmpl_type, 0x00, 0x00, slot_count, 0x00])

def _end() -> bytes:
    return b'\x00'

def _tmpl_sqrt(base_records: bytes) -> bytes:
    """SQRT: 1 slot (base)"""
    return _tmpl_header(T_SQRT, 1) + base_records + _end() + _end()

def _tmpl_sqrtn(index_records: bytes, base_records: bytes) -> bytes:
    """SQRT with index: 2 slots (index, base)"""
    return _tmpl_header(T_SQRT, 2) + index_records + _end() + base_records + _end() + _end()

def _tmpl_frac(num_records: bytes, den_records: bytes) -> bytes:
    """FRAC: two normal template slots (numerator, denominator).

    The previous hand-written special layout was not a valid general MTEF
    fraction record.  It is the direct cause of MathType's maximum-size
    warning for ordinary fractions.  Keep the standard slot framing used by
    the rest of this encoder.
    """
    return _tmpl_header(T_FRAC, 2) + num_records + _end() + den_records + _end() + _end()

def _tmpl_widehat(base_records: bytes) -> bytes:
    """WIDEHAT: 1 slot (base)"""
    return _tmpl_header(T_WIDEHAT, 1) + base_records + _end() + _end()

def _tmpl_frown(base_records: bytes) -> bytes:
    """FROWN (cung tròn): 1 slot (base) + glyph MT Extra"""
    return _tmpl_header(T_FROWN, 1) + base_records + _end() + _char('\u2322', TF_MTEXTRA) + _end() + _end()

def _tmpl_sup(base_records: bytes) -> bytes:
    """SUPERSCRIPT: 1 slot (base)"""
    return _tmpl_header(T_SUP, 1) + base_records + _end() + _end()

def _tmpl_sub(base_records: bytes) -> bytes:
    """SUBSCRIPT: 1 slot (base)"""
    return _tmpl_header(T_SUB, 1) + base_records + _end() + _end()

def _tmpl_subsup(sub_records: bytes, sup_records: bytes) -> bytes:
    """SUBSUP: 2 slots (sub, sup)"""
    return _tmpl_header(T_SUBSUP, 2) + sub_records + _end() + sup_records + _end() + _end()

def _tmpl_overline(base_records: bytes) -> bytes:
    """OVERLINE: 1 slot"""
    return _tmpl_header(T_OVERLINE, 1) + base_records + _end() + _end()

def _tmpl_underline(base_records: bytes) -> bytes:
    """UNDERLINE: 1 slot"""
    return _tmpl_header(T_UNDERLINE, 1) + base_records + _end() + _end()

def _tmpl_binom(top_records: bytes, bot_records: bytes) -> bytes:
    """BINOM: 2 slots"""
    return _tmpl_header(T_BINOM, 2) + top_records + _end() + bot_records + _end() + _end()

def _tmpl_integral(lower_records: bytes | None, upper_records: bytes | None,
                   base_records: bytes) -> bytes:
    """INTEGRAL: 3 slots (lower, upper, base)"""
    slots = []
    slots.append(lower_records if lower_records else _end())
    slots.append(_end())
    slots.append(upper_records if upper_records else _end())
    slots.append(_end())
    slots.append(base_records)
    slots.append(_end())
    return _tmpl_header(T_INTEGRAL, 3) + b''.join(slots) + _end()

def _tmpl_sum(lower_records: bytes | None, upper_records: bytes | None,
              base_records: bytes) -> bytes:
    """SUM: 3 slots (lower, upper, base)"""
    slots = []
    slots.append(lower_records if lower_records else _end())
    slots.append(_end())
    slots.append(upper_records if upper_records else _end())
    slots.append(_end())
    slots.append(base_records)
    slots.append(_end())
    return _tmpl_header(T_SUM, 3) + b''.join(slots) + _end()

def _tmpl_limit(lower_records: bytes, base_records: bytes) -> bytes:
    """LIMIT: 2 slots (lower, base)"""
    return _tmpl_header(T_LIMIT, 2) + lower_records + _end() + base_records + _end() + _end()

def _tmpl_overarrow(base_records: bytes, right: bool = True) -> bytes:
    """OVERARROW: 1 slot, subtype 0=right, 1=left, 2=both"""
    # TODO: handle left/both
    return _tmpl_header(T_OVERARROW, 1) + base_records + _end() + _end()


# ──────────────────────────────────────────────
# LaTeX tokenizer → MTEF records
# ──────────────────────────────────────────────

# Operators that use Symbol font
_SYMBOL_OPS = {
    '=': None, '+': None, '-': None, 
    '\\times': 0xD7, '\\div': 0xF7,
    '\\pm': 0xB1, '\\mp': 0xBF,
    '\\leq': 0xA3, '\\geq': 0xB3, '\\le': 0xA3, '\\ge': 0xB3,
    '\\neq': 0xB9, '\\approx': 0xBB,
    '\\equiv': 0xBA, '\\in': 0xCE,
    '\\subset': 0xCC, '\\supset': 0xC9,
    '\\cup': 0xC8, '\\cap': 0xC7,
    '\\cdot': 0xD7, '\\bullet': 0x2A,
    '\\to': 0xAE, '\\rightarrow': 0xAE,
    '\\leftarrow': 0xAC, '\\Rightarrow': 0xDE,
    '\\Leftarrow': 0xDC, '\\Leftrightarrow': 0xDB,
    '\\infty': 0xA5, '\\partial': 0xB6,
    '\\nabla': 0xD1, '\\exists': 0x24,
    '\\forall': 0x22, '\\emptyset': 0xE6,
    '\\angle': 0xD0, '\\perp': 0x5E,
    '\\mid': 0xBD, '\\propto': 0x5E,
    '\\circ': 0xB0, '\\bullet': 0x2A,
    '\\prime': 0xA2, '\\ldots': 0x2E,
    '\\cdots': 0xB7,
}

# Greek letters (lowercase)
_GREEK_LOWER = {
    'alpha': 0x61, 'beta': 0x62, 'gamma': 0x67, 'delta': 0x64,
    'epsilon': 0x65, 'zeta': 0x7A, 'eta': 0x68, 'theta': 0x71,
    'iota': 0x69, 'kappa': 0x6B, 'lambda': 0x6C, 'mu': 0x6D,
    'nu': 0x6E, 'xi': 0x78, 'omicron': 0x6F, 'pi': 0x70,
    'rho': 0x72, 'sigma': 0x73, 'tau': 0x74, 'upsilon': 0x75,
    'phi': 0x66, 'chi': 0x63, 'psi': 0x79, 'omega': 0x77,
    'varepsilon': 0x65, 'vartheta': 0x4A, 'varpi': 0x76,
    'varrho': 0x72, 'varsigma': 0x56, 'varphi': 0x6A,
}

# Greek letters (uppercase)
_GREEK_UPPER = {
    'Gamma': 0x47, 'Delta': 0x44, 'Theta': 0x51, 'Lambda': 0x4C,
    'Xi': 0x58, 'Pi': 0x50, 'Sigma': 0x53, 'Phi': 0x46,
    'Psi': 0x59, 'Omega': 0x57,
}

# Functions that render as text (Roman)
_FUNCTIONS = {
    'sin', 'cos', 'tan', 'cot', 'sec', 'csc',
    'log', 'ln', 'lg',
    'lim', 'max', 'min', 'sup', 'inf',
    'det', 'dim', 'ker', 'hom', 'arg',
    'deg', 'Pr',
}

def _tokenize_latex(s: str) -> list:
    """Tokenize LaTeX string thành list tokens.
    
    Mỗi token là tuple:
      ('char', ch)           - ký tự đơn
      ('cmd', name)          - lệnh LaTeX (vd 'frac', 'widehat')
      ('group', [tokens])    - nhóm { ... }
      ('sub', [tokens])      - subscript _ { ... }
      ('sup', [tokens])      - superscript ^ { ... }
      ('op', ch)             - toán tử = + - ...
    """
    tokens = []
    i = 0
    while i < len(s):
        c = s[i]
        
        if c == ' ' or c == '\t':
            i += 1
            continue
        
        if c == '{':
            # Find matching }
            depth = 1
            j = i + 1
            while j < len(s) and depth > 0:
                if s[j] == '{': depth += 1
                elif s[j] == '}': depth -= 1
                j += 1
            inner = s[i+1:j-1]
            tokens.append(('group', _tokenize_latex(inner)))
            i = j
            continue
        
        if c == '}':
            # Shouldn't happen at top level
            i += 1
            continue
        
        if c == '^':
            # Superscript
            if i + 1 < len(s):
                if s[i+1] == '{':
                    depth = 1
                    j = i + 2
                    while j < len(s) and depth > 0:
                        if s[j] == '{': depth += 1
                        elif s[j] == '}': depth -= 1
                        j += 1
                    inner = s[i+2:j-1]
                    tokens.append(('sup', _tokenize_latex(inner)))
                    i = j
                else:
                    # Single char superscript
                    tokens.append(('sup', [('char', s[i+1])]))
                    i += 2
            else:
                i += 1
            continue
        
        if c == '_':
            # Subscript
            if i + 1 < len(s):
                if s[i+1] == '{':
                    depth = 1
                    j = i + 2
                    while j < len(s) and depth > 0:
                        if s[j] == '{': depth += 1
                        elif s[j] == '}': depth -= 1
                        j += 1
                    inner = s[i+2:j-1]
                    tokens.append(('sub', _tokenize_latex(inner)))
                    i = j
                else:
                    tokens.append(('sub', [('char', s[i+1])]))
                    i += 2
            else:
                i += 1
            continue
        
        if c == '\\':
            # Command
            j = i + 1
            while j < len(s) and s[j].isalpha():
                j += 1
            cmd = s[i+1:j]
            
            # Check for operators with Symbol font
            full_cmd = '\\' + cmd
            if full_cmd in _SYMBOL_OPS:
                code = _SYMBOL_OPS[full_cmd]
                if code is not None:
                    tokens.append(('char_sym', chr(code)))
                else:
                    # None means use the char directly
                    pass
                i = j
                continue
            
            if cmd in _GREEK_LOWER:
                tokens.append(('char_sym', chr(_GREEK_LOWER[cmd])))
                i = j
                continue
            
            if cmd in _GREEK_UPPER:
                tokens.append(('char_sym', chr(_GREEK_UPPER[cmd])))
                i = j
                continue
            
            if cmd in _FUNCTIONS:
                tokens.append(('func', cmd))
                i = j
                continue
            
            # Commands that take arguments
            if cmd in ('frac', 'dfrac', 'tfrac', 'cfrac'):
                # Next two groups
                args = _consume_args(s, j)
                if args and len(args) >= 2:
                    tokens.append(('cmd', cmd, args[0][0], args[1][0]))
                    i = args[1][1]
                else:
                    i = j
                continue
            
            if cmd in ('sqrt',):
                # Optional [n] then {base}
                j2 = j
                index = None
                if j2 < len(s) and s[j2] == '[':
                    depth = 1
                    k = j2 + 1
                    while k < len(s) and depth > 0:
                        if s[k] == '[': depth += 1
                        elif s[k] == ']': depth -= 1
                        k += 1
                    index = _tokenize_latex(s[j2+1:k-1])
                    j2 = k
                base = _consume_one_group(s, j2)
                if base:
                    tokens.append(('cmd', 'sqrt', base[0], index))
                    i = base[1]
                else:
                    i = j
                continue
            
            if cmd in ('widehat', 'hat', 'tilde', 'vec', 'bar',
                       'overline', 'underline',
                       'overparen', 'wideparen', 'overarc',
                       'overrightarrow', 'overleftarrow',
                       'mathrm', 'mathbf', 'textit',
                       'text', 'boxed'):
                args = _consume_args(s, j)
                if args and len(args) >= 1:
                    tokens.append(('cmd', cmd, args[0][0]))
                    i = args[0][1]
                else:
                    i = j
                continue
            
            if cmd == 'binom':
                args = _consume_args(s, j)
                if args and len(args) >= 2:
                    tokens.append(('cmd', cmd, args[0][0], args[1][0]))
                    i = args[1][1]
                else:
                    i = j
                continue
            
            if cmd in ('left', 'right', 'big', 'Big', 'bigg', 'Bigg',
                       'bigl', 'bigr', 'Bigl', 'Bigr', 'biggl', 'biggr',
                       'Biggl', 'Biggr'):
                # Skip these - they're handled by LO
                # Next char is the delimiter
                if j < len(s):
                    i = j + 1
                else:
                    i = j
                continue
            
            if cmd in ('displaystyle', 'textstyle', 'scriptstyle',
                       'qquad', 'quad', ':', ';', '!', ' '):
                i = j
                continue
            
            # Unknown command - skip
            i = j
            continue
        
        if c in '=+-*/()[]|,.<>':
            tokens.append(('op', c))
            i += 1
            continue
        
        if c.isalnum():
            tokens.append(('char', c))
            i += 1
            continue
        
        i += 1
    
    return tokens

def _consume_args(s: str, pos: int) -> list | None:
    """Consume {group} arguments starting at pos. Returns [(tokens, end_pos), ...] or None."""
    args = []
    i = pos
    while i < len(s):
        c = s[i]
        if c == '{':
            depth = 1
            j = i + 1
            while j < len(s) and depth > 0:
                if s[j] == '{': depth += 1
                elif s[j] == '}': depth -= 1
                j += 1
            inner = s[i+1:j-1]
            args.append((_tokenize_latex(inner), j))
            i = j
        elif c == ' ' or c == '\t':
            i += 1
            continue
        else:
            break
    if args:
        return args
    return None

def _consume_one_group(s: str, pos: int):
    """Consume one {group}. Returns (tokens, end_pos) or None."""
    i = pos
    while i < len(s) and s[i] in ' \t':
        i += 1
    if i < len(s) and s[i] == '{':
        depth = 1
        j = i + 1
        while j < len(s) and depth > 0:
            if s[j] == '{': depth += 1
            elif s[j] == '}': depth -= 1
            j += 1
        inner = s[i+1:j-1]
        return (_tokenize_latex(inner), j)
    return None


# ──────────────────────────────────────────────
# Token tree → MTEF records
# ──────────────────────────────────────────────

def _tokens_to_mtef(tokens: list, is_var: bool = False) -> bytes:
    """Convert token list to MTEF records.
    
    is_var: True nếu đang trong context biến (FROWN base, subscript...)
    """
    result = bytearray()
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        ttype = tok[0]
        
        if ttype == 'char':
            ch = tok[1]
            if ch.isdigit():
                result += _char(ch, TF_TEXT)
            elif ch.isalpha():
                # Letters in math mode use variable style (Symbol) by default
                # But for FROWN base we use Symbol font
                if is_var:
                    result += _char(ch, TF_VAR)
                else:
                    result += _char(ch, TF_TEXT)
            else:
                result += _char(ch, TF_TEXT)
            i += 1
        
        elif ttype == 'char_sym':
            ch = tok[1]
            result += _char(ch, TF_VAR)
            i += 1
        
        elif ttype == 'op':
            ch = tok[1]
            if ch in '=+-':
                result += _char(ch, TF_VAR)
            elif ch in '()[]':
                result += _char(ch, TF_TEXT)
            elif ch in '|,':
                result += _char(ch, TF_TEXT)
            elif ch == '.':
                result += _char(ch, TF_TEXT)
            else:
                result += _char(ch, TF_TEXT)
            i += 1
        
        elif ttype == 'func':
            name = tok[1]
            result += _chars(name, TF_TEXT)
            i += 1
        
        elif ttype == 'group':
            inner = _tokens_to_mtef(tok[1], is_var)
            result += inner
            i += 1
        
        elif ttype == 'sub':
            inner = _tokens_to_mtef(tok[1], True)
            # Check if next token is sup
            if i + 1 < len(tokens) and tokens[i+1][0] == 'sup':
                sup_inner = _tokens_to_mtef(tokens[i+1][1], True)
                result += _tmpl_subsup(inner, sup_inner)
                i += 2
            else:
                result += _tmpl_sub(inner)
                i += 1
        
        elif ttype == 'sup':
            inner = _tokens_to_mtef(tok[1], True)
            result += _tmpl_sup(inner)
            i += 1
        
        elif ttype == 'cmd':
            cmd = tok[1]
            
            if cmd in ('frac', 'dfrac', 'tfrac', 'cfrac'):
                num = _tokens_to_mtef(tok[2], False)
                den = _tokens_to_mtef(tok[3], False)
                result += _tmpl_frac(num, den)
                i += 1
            
            elif cmd == 'sqrt':
                base = _tokens_to_mtef(tok[2], False) if tok[2] else b''
                index = _tokens_to_mtef(tok[3], False) if tok[3] else None
                if index:
                    result += _tmpl_sqrtn(index, base)
                else:
                    result += _tmpl_sqrt(base)
                i += 1
            
            elif cmd in ('widehat',):
                base = _tokens_to_mtef(tok[2], False)
                result += _tmpl_widehat(base)
                i += 1
            
            elif cmd == 'hat':
                base = _tokens_to_mtef(tok[2], False)
                # Single char hat → embellishment
                # Multi char → widehat
                if len(tok[2]) == 1 and tok[2][0][0] == 'char':
                    ch = tok[2][0][1]
                    result += _char(ch, TF_TEXT, EMBELL_HAT)
                else:
                    result += _tmpl_widehat(base)
                i += 1
            
            elif cmd == 'tilde':
                base = _tokens_to_mtef(tok[2], False)
                if len(tok[2]) == 1 and tok[2][0][0] == 'char':
                    ch = tok[2][0][1]
                    result += _char(ch, TF_TEXT, EMBELL_TILDE)
                else:
                    result += _tmpl_overline(base)  # approximate
                i += 1
            
            elif cmd == 'vec':
                base = _tokens_to_mtef(tok[2], False)
                if len(tok[2]) == 1 and tok[2][0][0] == 'char':
                    ch = tok[2][0][1]
                    result += _char(ch, TF_TEXT, EMBELL_VEC)
                else:
                    result += _tmpl_overarrow(base)
                i += 1
            
            elif cmd == 'bar':
                base = _tokens_to_mtef(tok[2], False)
                if len(tok[2]) == 1 and tok[2][0][0] == 'char':
                    ch = tok[2][0][1]
                    result += _char(ch, TF_TEXT, EMBELL_BAR)
                else:
                    result += _tmpl_overline(base)
                i += 1
            
            elif cmd == 'overline':
                base = _tokens_to_mtef(tok[2], False)
                result += _tmpl_overline(base)
                i += 1
            
            elif cmd == 'underline':
                base = _tokens_to_mtef(tok[2], False)
                result += _tmpl_underline(base)
                i += 1
            
            elif cmd in ('overparen', 'wideparen', 'overarc'):
                base = _tokens_to_mtef(tok[2], True)  # is_var=True → Symbol font
                result += _tmpl_frown(base)
                i += 1
            
            elif cmd in ('overrightarrow',):
                base = _tokens_to_mtef(tok[2], False)
                result += _tmpl_overarrow(base, right=True)
                i += 1
            
            elif cmd in ('overleftarrow',):
                base = _tokens_to_mtef(tok[2], False)
                result += _tmpl_overarrow(base, right=False)
                i += 1
            
            elif cmd in ('mathrm', 'text'):
                base = _tokens_to_mtef(tok[2], False)
                result += base  # Already TF_TEXT
                i += 1
            
            elif cmd == 'mathbf':
                # Bold - same as text for now
                base = _tokens_to_mtef(tok[2], False)
                result += base
                i += 1
            
            elif cmd == 'binom':
                top = _tokens_to_mtef(tok[2], False)
                bot = _tokens_to_mtef(tok[3], False) if len(tok) > 3 else b''
                result += _tmpl_binom(top, bot)
                i += 1
            
            elif cmd == 'boxed':
                base = _tokens_to_mtef(tok[2], False)
                result += base
                i += 1
            
            else:
                i += 1
        
        else:
            i += 1
    
    return bytes(result)


# ──────────────────────────────────────────────
# Main API
# ──────────────────────────────────────────────

# MTEF v3 header copied from an Equation Native stream exported by LibreOffice.
# Unlike the former hand-written v5 preamble, MathType 7 opens this profile
# directly for editing.  cbObject (offset 8) is replaced for every formula.
_V3_NATIVE_HEADER = bytes.fromhex(
    "1c0000000200c6c10000000000000000ffffff0fffffff0f00000000"
)
_V3_ROOT_PREFIX = bytes.fromhex("03010103000a010a01")

_V3_SYMBOL_CHARS = {
    0x61: "α", 0x62: "β", 0x67: "γ", 0x64: "δ", 0x65: "ε",
    0x7A: "ζ", 0x68: "η", 0x71: "θ", 0x69: "ι", 0x6B: "κ",
    0x6C: "λ", 0x6D: "μ", 0x6E: "ν", 0x78: "ξ", 0x6F: "ο",
    0x70: "π", 0x72: "ρ", 0x73: "σ", 0x74: "τ", 0x75: "υ",
    0x66: "φ", 0x63: "χ", 0x79: "ψ", 0x77: "ω", 0x47: "Γ",
    0x44: "Δ", 0x51: "Θ", 0x4C: "Λ", 0x58: "Ξ", 0x50: "Π",
    0x53: "Σ", 0x46: "Φ", 0x59: "Ψ", 0x57: "Ω", 0xD7: "×",
    0xF7: "÷", 0xB1: "±", 0xBF: "∓", 0xA3: "≤", 0xB3: "≥",
    0xB9: "≠", 0xBB: "≈", 0xBA: "≡", 0xCE: "∈", 0xCC: "⊂",
    0xC9: "⊃", 0xC8: "∪", 0xC7: "∩", 0xAE: "→", 0xAC: "←",
    0xDE: "⇒", 0xDC: "⇐", 0xDB: "⇔", 0xA5: "∞", 0xB6: "∂",
    0xD1: "∇", 0xE6: "∅", 0xD0: "∠", 0xB0: "°",
}


def _v3_char(ch: str, text: bool = False) -> bytes:
    """MTEF v3 CHAR: use Variable for math letters, Text for digits/functions."""
    typeface = 0x81 if text or ch.isdigit() else 0x83
    return b"\x02" + bytes((typeface,)) + ch.encode("utf-16le")


def _v3_line(records: bytes) -> bytes:
    return b"\x0a\x01" + records + b"\x00"


def _tokens_to_mtef_v3(tokens: list, text: bool = False) -> bytes:
    """Encode the safe native subset using the MathType-readable v3 layout."""
    out = bytearray()
    for pos, token in enumerate(tokens):
        kind = token[0]
        if kind == "char":
            out += _v3_char(token[1], text=text)
        elif kind == "char_sym":
            out += _v3_char(_V3_SYMBOL_CHARS.get(ord(token[1]), token[1]))
        elif kind == "op":
            if token[1] == "-":
                # LO uses a Unicode minus in the Symbol typeface.
                out += bytes.fromhex("02861222")
            elif token[1] in "<>":
                # Comparison operators use Variable typeface
                out += _v3_char(token[1], text=False)
            else:
                out += _v3_char(token[1], text=token[1] in "()[]|,.")
        elif kind == "func":
            out += b"".join(_v3_char(ch, text=True) for ch in token[1])
        elif kind == "group":
            out += _tokens_to_mtef_v3(token[1], text=text)
        elif kind == "cmd" and token[1] in ("frac", "dfrac", "tfrac", "cfrac"):
            numerator = _tokens_to_mtef_v3(token[2])
            denominator = _tokens_to_mtef_v3(token[3])
            # TMPL fraction: two LINE slots, followed by template END.
            out += b"\x03\x0e\x00\x00" + _v3_line(numerator) + _v3_line(denominator) + b"\x00"
        elif kind == "cmd" and token[1] == "sqrt":
            if token[3] is not None:
                raise ValueError("indexed roots are not in the native v3 subset")
            # MathType's v3 root template uses Text records in its radicand
            # slot; this is the layout emitted by the known-good LO stream.
            radicand = _tokens_to_mtef_v3(token[2], text=True)
            # tmROOT: radicand followed by the empty index slot.
            out += b"\x03\x0d\x00\x00\x01" + radicand + b"\x00\x11\x00"
        elif kind == "sup":
            exponent = _tokens_to_mtef_v3(token[1], text=True)
            # This is the exact superscript template framing emitted by LO.
            out += b"\x03\x0f\x00\x00\x0b\x11\x01" + exponent + b"\x00\x00"
            # LO emits a continuation marker after every script, including
            # the final atom within a root/template slot.
            out += b"\x0a"
        elif kind == "sub":
            # MTEF v3 subscript: use SUBSUP template with BOTH slots filled
            # (empty sup slot 0x11 + filled sub slot 0x12) to keep structure valid.
            subscript = _tokens_to_mtef_v3(token[1], text=True)
            out += b"\x03\x0f\x00\x00\x0b\x11\x01\x00\x12\x01" + subscript + b"\x00\x00"
            out += b"\x0a"
        elif kind == "cmd" and token[1] in ("mathrm", "text"):
            out += _tokens_to_mtef_v3(token[2], text=True)
        else:
            # can_encode_native_mtef() rejects constructs that would land here.
            raise ValueError(f"unsupported native MTEF token: {token!r}")
    return bytes(out)


def latex_to_mtef(latex: str) -> bytes:
    """Convert the supported LaTeX subset to an editable MTEF v3 stream.

    The stream is intentionally modelled on a real LibreOffice Equation
    Native object, but is constructed locally and does not start LibreOffice.
    """
    source = latex.strip()
    if source.startswith("$$") and source.endswith("$$"):
        source = source[2:-2].strip()
    elif source.startswith("$") and source.endswith("$"):
        source = source[1:-1].strip()
    source = re.sub(r"\\(?:displaystyle|textstyle)\s*", "", source)
    body = _V3_ROOT_PREFIX + _tokens_to_mtef_v3(_tokenize_latex(source)) + b"\x00\x00\x00"
    header = bytearray(_V3_NATIVE_HEADER)
    struct.pack_into("<I", header, 8, len(body))
    return bytes(header) + body


def latex_to_ole_bytes(latex: str) -> bytes:
    """Convert LaTeX to full OLE bytes (4 streams).
    
    Returns: bytes of OLE compound file ready for embedding in docx.
    """
    from .mathtype_ole_builder import make_mathtype_ole
    mtef = latex_to_mtef(latex)
    return make_mathtype_ole(mtef)


# ──────────────────────────────────────────────
# Self-test
# ──────────────────────────────────────────────

def selftest():
    """Verify against Doc3.doc and test various formulas."""
    import olefile
    
    # Test 1: Doc3 formula
    doc3_latex = r"\widehat{ACB}=\frac{1}{2}sd\overparen{ABC}"
    mtef = latex_to_mtef(doc3_latex)
    
    # Compare with Doc3
    ole = olefile.OleFileIO('Doc3.doc')
    doc3_mtef = ole.openstream('ObjectPool/_1846005202/Equation Native').read()
    ole.close()
    
    print(f"Doc3 MTEF: {len(doc3_mtef)} bytes")
    print(f"Our MTEF:  {len(mtef)} bytes")
    
    # Check header
    assert mtef[:4] == doc3_mtef[:4], "Header size mismatch"
    assert mtef[4:8] == doc3_mtef[4:8], "Header version/platform mismatch"
    
    # Check font table (bytes 28-219)
    assert mtef[28:219] == doc3_mtef[28:219], "Font table mismatch"
    
    # Check formula records (after size block)
    # Find LINE_START in both
    def find_line_start(data):
        for i in range(28, len(data)):
            if data[i:i+5] == b'\x0a\x01\x00\x01\x00':
                return i
        return -1
    
    pos_doc3 = find_line_start(doc3_mtef)
    pos_ours = find_line_start(mtef)
    
    print(f"Doc3 LINE_START at offset {pos_doc3}")
    print(f"Our LINE_START at offset {pos_ours}")
    
    # The formula records should be equivalent
    doc3_formula = doc3_mtef[pos_doc3:]
    our_formula = mtef[pos_ours:]
    
    print(f"Doc3 formula: {doc3_formula.hex()}")
    print(f"Our formula:  {our_formula.hex()}")
    
    # They should be identical for the Doc3 formula
    if doc3_formula == our_formula:
        print("✅ Doc3 formula: IDENTICAL!")
    else:
        print("⚠ Doc3 formula: differs (may be equivalent)")
        # Show differences
        for i in range(min(len(doc3_formula), len(our_formula))):
            if doc3_formula[i] != our_formula[i]:
                print(f"  Diff at byte {i}: Doc3={doc3_formula[i]:02x} Ours={our_formula[i]:02x}")
                print(f"  Doc3 ctx: {doc3_formula[max(0,i-4):i+8].hex()}")
                print(f"  Our ctx:  {our_formula[max(0,i-4):i+8].hex()}")
                break
    
    # Test 2: Pure arc
    print("\n--- Test 2: Pure arc ---")
    mtef2 = latex_to_mtef(r"\overparen{AB}")
    print(f"Pure arc: {len(mtef2)} bytes")
    print(f"Formula: {mtef2[pos_ours:].hex()}")
    
    # Test 3: Arc with sqrt
    print("\n--- Test 3: Arc with sqrt ---")
    mtef3 = latex_to_mtef(r"\sqrt{\overparen{AB}^2 + \overparen{CD}^2}")
    print(f"Sqrt arc: {len(mtef3)} bytes")
    pos3 = find_line_start(mtef3)
    print(f"Formula: {mtef3[pos3:].hex()}")
    
    # Test 4: Complex mixed
    print("\n--- Test 4: Complex mixed ---")
    mtef4 = latex_to_mtef(r"\lim_{x\to 0}\frac{\sin x}{x} = \overparen{AB}")
    print(f"Complex: {len(mtef4)} bytes")
    pos4 = find_line_start(mtef4)
    print(f"Formula: {mtef4[pos4:].hex()}")
    
    # Test 5: Arc with hat and frac
    print("\n--- Test 5: Hat + frac + arc ---")
    mtef5 = latex_to_mtef(r"\widehat{A} = \frac{\overparen{BC}}{2}")
    print(f"Hat+frac+arc: {len(mtef5)} bytes")
    pos5 = find_line_start(mtef5)
    print(f"Formula: {mtef5[pos5:].hex()}")
    
    # Test 6: Multiple arcs
    print("\n--- Test 6: Multiple arcs ---")
    mtef6 = latex_to_mtef(r"\overparen{A} + \overparen{B} = \overparen{AB}")
    print(f"Multi arc: {len(mtef6)} bytes")
    pos6 = find_line_start(mtef6)
    print(f"Formula: {mtef6[pos6:].hex()}")
    
    print("\n✅ All tests completed!")


if __name__ == "__main__":
    selftest()
