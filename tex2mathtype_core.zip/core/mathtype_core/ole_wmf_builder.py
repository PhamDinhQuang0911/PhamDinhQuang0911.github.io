import base64
import math
import os
import struct
import time
import zlib
from fontTools.pens.recordingPen import DecomposingRecordingPen
from fontTools.ttLib import TTFont

# Compressed 3072-byte reference OLE2 Compound Document template (MathType 7 Equation.DSMT4)
_OLE_BASE_B64 = (
    "eNq7cF7wwcKNUg8Z0IAdAzPDv/+cDGxIYoxQDAYCDAxMUP6/////w4T/j4IhBf4CMQs0DmF4FIwcEMSQD4QlDAoMrgx5QLq"
    "IoZKBFCDGwArP86DygPkcE1j8AETaDZseZpA8I6xM8WfIYUhlIBdwMTAxIvuHWH0i8DLNGej/XIYCoDuSGLJItl8IaD8j"
    "1E/E2g9SnwkPC4i9nsDQTwO6hBz7/0PzMLH2g9wKK9f/QeMNlvdZoXKj5cDIAMC0yMTBQD5gBKYUZi5I2kPP+2JAwjex"
    "JCOksiBVwVzPQMG1sDSxJDM/j4EHWcbVjYEfyIdJ6rkE+4aYMHyx3FTIQFxqZqHA/TIMoHaM3iFYzm/oO5ule/8YmGZl"
    "ZGBnAbnGnIFRODwzzzEnxymxODPZOT8lNSAxPbWYQZA1JDM3tVjBL7VcISg/NzGPQZA5uDI3KT8HKOWcX1qUmVoEkmQQ"
    "ZPENUXCtKClKZOBiBFrY7Asi/EBEAMNAAleGQoZShkRgyZ8JLH3ygPWAH5RXRlSprAD0AqnlLyi+2qjoB3LKf4ZR+8EAACqWRwA="
)
_OLE_TEMPLATE = zlib.decompress(base64.b64decode(_OLE_BASE_B64))

OLE_HEADER = _OLE_TEMPLATE[0:512]
DIR_SEC1_BASE = _OLE_TEMPLATE[1024:1536]
MINISTREAM_PREFIX = _OLE_TEMPLATE[2048:2304]
DIR_SEC4_BASE = _OLE_TEMPLATE[2560:3072]


def build_ole_object(mtef: bytes, ts1: int | None = None, ts2: int = 13033261) -> bytes:
    """Wrap raw MTEF v5 bytes into a valid OLE2 Compound File (Equation.DSMT4)."""
    if ts1 is None:
        ts1 = int(time.time()) & 0xFFFFFFFF
    eq_hdr = struct.pack("<HHIIIIII", 28, 0, 3257794562, len(mtef), 0, ts1, ts2, ts1)
    eq_stream = eq_hdr + mtef
    eq_len = len(eq_stream)
    n_eq_mini = (eq_len + 63) // 64
    total_mini = 4 + n_eq_mini
    ministream_size = total_mini * 64
    n_mini_secs = (ministream_size + 511) // 512

    # 1. Sector 0: FAT (512 bytes)
    fat = [0xFFFFFFFF] * 128
    fat[0] = 0xFFFFFFFD  # FAT sector
    fat[1] = 4  # Dir sector 1 -> Dir sector 4
    fat[2] = 0xFFFFFFFE  # MiniFAT sector
    fat[4] = 0xFFFFFFFE  # End of Dir chain
    if n_mini_secs == 1:
        fat[3] = 0xFFFFFFFE
    else:
        fat[3] = 5
        for s in range(5, 5 + n_mini_secs - 2):
            fat[s] = s + 1
        fat[5 + n_mini_secs - 2] = 0xFFFFFFFE
    sec0 = struct.pack("<128I", *fat)

    # 2. Sector 1: Directory part 1 (512 bytes)
    sec1 = bytearray(DIR_SEC1_BASE)
    struct.pack_into("<I", sec1, 120, ministream_size)

    # 3. Sector 2: MiniFAT (512 bytes)
    minifat = [0xFFFFFFFF] * 128
    minifat[0] = 0xFFFFFFFE  # \x01Ole
    minifat[1] = 2  # \x01CompObj
    minifat[2] = 0xFFFFFFFE
    minifat[3] = 0xFFFFFFFE  # \x03ObjInfo
    for k in range(4, min(128, 4 + n_eq_mini - 1)):
        minifat[k] = k + 1
    if 4 + n_eq_mini - 1 < 128:
        minifat[4 + n_eq_mini - 1] = 0xFFFFFFFE
    sec2 = struct.pack("<128I", *minifat)

    # 4. Sector 4: Directory part 2 (512 bytes)
    sec4 = bytearray(DIR_SEC4_BASE)
    struct.pack_into("<I", sec4, 120, eq_len)

    # 5. MiniStream (padded to n_mini_secs * 512 bytes)
    full_ministream = bytearray(n_mini_secs * 512)
    full_ministream[0:256] = MINISTREAM_PREFIX
    full_ministream[256 : 256 + eq_len] = eq_stream
    sec3 = bytes(full_ministream[0:512])
    extra_secs = bytes(full_ministream[512:])

    return OLE_HEADER + sec0 + bytes(sec1) + sec2 + sec3 + bytes(sec4) + extra_secs


def build_wmf_from_polygons(polygons: list[list[tuple[int, int]]], r: int, b: int, inch: int) -> bytes:
    """Build a 10-record Aldus Placeable WMF with META_POLYPOLYGON (0x0538)."""
    valid_polys = [p for p in polygons if len(p) >= 3]
    if not valid_polys:
        valid_polys = [[(0, 0), (1, 0), (1, 1)]]
    n_polys = len(valid_polys)
    counts_bytes = struct.pack(f"<{n_polys}H", *[len(p) for p in valid_polys])
    pts_list = []
    for p in valid_polys:
        for x, y in p:
            cx = max(-32768, min(32767, int(round(x))))
            cy = max(-32768, min(32767, int(round(y))))
            pts_list.append(struct.pack("<hh", cx, cy))
    poly_payload = struct.pack("<H", n_polys) + counts_bytes + b"".join(pts_list)

    rec8_words = 3 + len(poly_payload) // 2
    total_words = 53 + rec8_words
    max_rec_words = max(8, rec8_words)

    r_clamped = max(1, min(32767, int(round(r))))
    b_clamped = max(1, min(32767, int(round(b))))
    inch_clamped = max(72, min(65535, int(round(inch))))

    apm_body = struct.pack("<IHhhhhHI", 0x9AC6CDD7, 0, 0, 0, r_clamped, b_clamped, inch_clamped, 0)
    csum = 0
    for w16 in struct.unpack("<10H", apm_body):
        csum ^= w16
    apm_hdr = apm_body + struct.pack("<H", csum)

    wmf_hdr = struct.pack("<HHHIHIH", 1, 9, 0x0300, total_words, 2, max_rec_words, 0)
    recs_0_7 = (
        struct.pack("<IHH", 4, 0x0103, 8)
        + struct.pack("<IHhh", 5, 0x020B, 0, 0)
        + struct.pack("<IHhh", 5, 0x020C, b_clamped, r_clamped)
        + struct.pack("<IHH", 4, 0x0106, 2)
        + struct.pack("<IHHHHHH", 8, 0x02FA, 5, 0, 0, 0, 0)
        + struct.pack("<IHH", 4, 0x012D, 0)
        + struct.pack("<IHHHHH", 7, 0x02FC, 0, 0, 0, 0)
        + struct.pack("<IHH", 4, 0x012D, 1)
    )
    rec_8 = struct.pack("<IH", rec8_words, 0x0538) + poly_payload
    rec_9 = struct.pack("<IH", 3, 0x0000)
    return apm_hdr + wmf_hdr + recs_0_7 + rec_8 + rec_9


class FontOutlineCache:
    """Fast TrueType glyph contour & metric cache using fontTools."""

    def __init__(self):
        search_dirs = [
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts"),
            "/fonts",
            os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts") if (os.environ.get("WINDIR") or os.path.exists(r"C:\Windows\Fonts")) else "",
            "/usr/share/fonts/truetype/msttcorefonts",
            "/usr/share/fonts/truetype",
            "/usr/share/fonts",
        ]
        search_dirs = [d for d in search_dirs if d and os.path.isdir(d)]

        self.fonts = {}
        self.cmaps = {}
        self.glyph_sets = {}
        self.hmtxs = {}
        self.upems = {}

        font_files = {
            "roman": ["times.ttf", "Times.ttf", "LiberationSerif-Regular.ttf", "FreeSerif.ttf"],
            "italic": ["timesi.ttf", "Timesi.ttf", "LiberationSerif-Italic.ttf", "FreeSerifItalic.ttf"],
            "bold": ["timesbd.ttf", "Timesbd.ttf", "LiberationSerif-Bold.ttf", "FreeSerifBold.ttf"],
            "symbol": ["symbol.ttf", "Symbol.ttf", "OpenSymbol.ttf"],
            "seguisym": ["seguisym.ttf", "Seguisym.ttf"],
            "mtextra": ["mtextra.ttf", "Mtextra.ttf"],
        }

        # Try to resolve each font key
        for key, candidates in font_files.items():
            for d in search_dirs:
                found = False
                for fn in candidates:
                    fp = os.path.join(d, fn)
                    if os.path.exists(fp):
                        try:
                            tt = TTFont(fp)
                            self.fonts[key] = tt
                            self.cmaps[key] = self._build_cmap(tt)
                            self.glyph_sets[key] = tt.getGlyphSet()
                            self.hmtxs[key] = tt["hmtx"]
                            self.upems[key] = tt["head"].unitsPerEm
                            found = True
                            break
                        except Exception:
                            pass
                if found:
                    break

        self._cache = {}

    @staticmethod
    def _build_cmap(tt: TTFont) -> dict[int, str]:
        cmap = {}
        for table in tt["cmap"].tables:
            if table.cmap:
                cmap.update(table.cmap)
        best = tt.getBestCmap()
        if best:
            cmap.update(best)
        return cmap

    def get_glyph(self, style: str, codepoint: int):
        """
        Return (advance_em, lsb_em, bbox_em, contours_em) where coordinates are normalized
        to 1.0 em (i.e. divided by unitsPerEm, with y > 0 upward).
        """
        cache_key = (style, codepoint)
        if cache_key in self._cache:
            return self._cache[cache_key]

        if codepoint == 0x223D and "seguisym" in self.fonts:
            style = "seguisym"

        if style not in self.fonts:
            style = "roman"

        if style not in self.fonts or style not in self.cmaps:
            res = (0.5, 0.0, (0.0, 0.0, 0.5, 0.7), [])
            self._cache[cache_key] = res
            return res

        cmap = self.cmaps[style]
        gname = cmap.get(codepoint)
        if not gname and style in ("symbol", "mtextra"):
            # Symbol/MT Extra private use area mapping (0xF000 + byte)
            gname = cmap.get(0xF000 + (codepoint & 0xFF)) or cmap.get(codepoint & 0xFF)
        if not gname and style != "roman":
            if "seguisym" in self.fonts and codepoint in self.cmaps["seguisym"]:
                style = "seguisym"
                cmap = self.cmaps["seguisym"]
                gname = cmap.get(codepoint)
            elif "roman" in self.fonts and "roman" in self.cmaps:
                style = "roman"
                cmap = self.cmaps["roman"]
                gname = cmap.get(codepoint)
            else:
                gname = None

        if not gname:
            res = (0.5, 0.0, (0.0, 0.0, 0.5, 0.7), [])
            self._cache[cache_key] = res
            return res

        upem = float(self.upems[style])
        adv_raw, lsb_raw = self.hmtxs[style][gname]
        adv = adv_raw / upem
        lsb = lsb_raw / upem

        pen = DecomposingRecordingPen(self.glyph_sets[style])
        self.glyph_sets[style][gname].draw(pen)

        contours = []
        curr = []
        p0 = (0.0, 0.0)

        for op, args in pen.value:
            if op == "moveTo":
                if curr:
                    contours.append(curr)
                pt = (args[0][0] / upem, args[0][1] / upem)
                curr = [pt]
                p0 = pt
            elif op == "lineTo":
                pt = (args[0][0] / upem, args[0][1] / upem)
                curr.append(pt)
                p0 = pt
            elif op == "qCurveTo":
                pts = [(p[0] / upem, p[1] / upem) if p is not None else None for p in args]
                if pts[-1] is None:
                    # TrueType all-off-curve closed contour
                    off = pts[:-1]
                    if len(off) >= 2:
                        p0 = ((off[-1][0] + off[0][0]) * 0.5, (off[-1][1] + off[0][1]) * 0.5)
                        curr = [p0]
                        for i in range(len(off)):
                            c = off[i]
                            nxt = off[(i + 1) % len(off)]
                            p1 = ((c[0] + nxt[0]) * 0.5, (c[1] + nxt[1]) * 0.5)
                            self._flatten_quad(curr, p0, c, p1)
                            p0 = p1
                else:
                    off = pts[:-1]
                    end_pt = pts[-1]
                    if not off:
                        curr.append(end_pt)
                        p0 = end_pt
                    else:
                        for i in range(len(off) - 1):
                            c = off[i]
                            nxt = off[i + 1]
                            mid = ((c[0] + nxt[0]) * 0.5, (c[1] + nxt[1]) * 0.5)
                            self._flatten_quad(curr, p0, c, mid)
                            p0 = mid
                        self._flatten_quad(curr, p0, off[-1], end_pt)
                        p0 = end_pt
            elif op in ("closePath", "endPath"):
                if len(curr) >= 3:
                    contours.append(curr)
                curr = []

        if len(curr) >= 3:
            contours.append(curr)

        if contours:
            xs = [pt[0] for c in contours for pt in c]
            ys = [pt[1] for c in contours for pt in c]
            bbox = (min(xs), min(ys), max(xs), max(ys))
        else:
            bbox = (0.0, 0.0, adv, 0.0)

        res = (adv, lsb, bbox, contours)
        self._cache[cache_key] = res
        return res

    @staticmethod
    def _flatten_quad(out_pts: list, p0: tuple[float, float], c: tuple[float, float], p1: tuple[float, float], steps: int = 6):
        x0, y0 = p0
        cx, cy = c
        x1, y1 = p1
        for s in range(1, steps + 1):
            t = s / steps
            mt = 1.0 - t
            x = mt * mt * x0 + 2.0 * mt * t * cx + t * t * x1
            y = mt * mt * y0 + 2.0 * mt * t * cy + t * t * y1
            out_pts.append((x, y))
