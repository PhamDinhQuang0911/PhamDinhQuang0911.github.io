# mathtype_core package
