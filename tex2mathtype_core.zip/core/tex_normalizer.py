r"""
tex_normalizer.py - Chuẩn hóa câu hỏi LaTeX và xây dựng Word Document nền trắng (Không header, không footer, không background).
Hỗ trợ các chuẩn Word BTPRO (btn_group, dang1, dang3, dang4, dang5).
Xử lý toàn diện TiKZ, Tabular, Includegraphics, \chapter, \True...
"""

import os
import re
import sys
import shutil
import subprocess
import tempfile
from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

# ────────────────────────────────────────────────────────────
# BỘ THIẾT LẬP CHUẨN HÓA WORD THEO BTPRO (BTPRO2022.dotm)
# ────────────────────────────────────────────────────────────
WORD_STANDARDS = {
    'btn_group': {
        'name': 'Chuẩn BTN Group (Mặc định)',
        'margins': (2.0, 1.0, 1.0, 1.0),   # Left, Right, Top, Bottom (cm)
        'q_indent': (1.75, -1.75),          # LeftIndent, FirstLineIndent (cm)
        'c_indent': (1.75, 0.0),            # Choice LeftIndent, FirstLineIndent (cm)
        'tabs_4col': (6.0, 10.0, 14.0),     # Tab stops for 4 cols (cm)
        'tabs_2col': (10.0,),               # Tab stop for 2 cols (cm)
        'chia1': 24,
        'chia2': 45,
    },
    'dang1': {
        'name': 'Dạng 1 (Chuẩn thường)',
        'margins': (1.5, 1.0, 1.5, 1.5),
        'q_indent': (0.0, 0.5),
        'c_indent': (0.0, 0.5),
        'tabs_4col': (5.0, 9.5, 14.0),
        'tabs_2col': (9.5,),
        'chia1': 24,
        'chia2': 45,
    },
    'dang3': {
        'name': 'Dạng 3 (A4 chia cột tự động)',
        'margins': (2.0, 1.5, 1.5, 1.5),
        'q_indent': (0.5, -0.5),
        'c_indent': (0.5, 0.0),
        'tabs_4col': (5.0, 9.5, 14.0),
        'tabs_2col': (9.5,),
        'chia1': 24,
        'chia2': 45,
    },
    'dang4': {
        'name': 'Dạng 4 (In 2 cột / Trang hẹp)',
        'margins': (1.5, 1.0, 1.0, 1.0),
        'q_indent': (0.5, -0.5),
        'c_indent': (0.5, 0.0),
        'tabs_4col': (2.3, 4.5, 6.7),
        'tabs_2col': (4.5,),
        'chia1': 16,
        'chia2': 30,
    },
    'dang5': {
        'name': 'Dạng 5 (Tiết kiệm diện tích)',
        'margins': (1.0, 1.0, 1.0, 1.0),
        'q_indent': (0.2, -0.2),
        'c_indent': (0.2, 0.0),
        'tabs_4col': (2.0, 4.2, 6.4),
        'tabs_2col': (4.2,),
        'chia1': 13,
        'chia2': 25,
    },
}


def strip_preamble(text: str) -> str:
    """Loại bỏ phần preamble và các lệnh cấu hình môi trường LaTeX."""
    m = re.search(r'\\begin\s*\{document\}', text)
    if m:
        text = text[m.end():]
    text = re.sub(r'\\end\s*\{document\}', '', text)
    pats = [
        r'\\documentclass(\[.*?\])?\{[^}]*\}',
        r'\\usepackage(\[.*?\])?\{[^}]*\}',
        r'\\pagestyle\{[^}]*\}',
        r'\\thispagestyle\{[^}]*\}',
        r'\\fancyhead(\[.*?\])?\{[^}]*\}',
        r'\\fancyfoot(\[.*?\])?\{[^}]*\}',
        r'\\fancypagestyle\{[^}]*\}\{[^}]*\}',
        r'\\renewcommand\{\\headrulewidth\}\{[^}]*\}',
        r'\\renewcommand\{\\footrulewidth\}\{[^}]*\}',
        r'\\setcounter\{[^}]*\}\{[^}]*\}',
        r'\\geometry\{[^}]*\}',
        r'\\makeatletter', r'\\makeatother',
        r'\\newcommand\{[^}]*\}(\[.*?\])?\{[^}]*\}',
        r'\\providecommand\{[^}]*\}(\[.*?\])?\{[^}]*\}',
    ]
    for p in pats:
        text = re.sub(p, '', text, flags=re.DOTALL)
    text = re.sub(r'\\begin\{minipage\}.*?\\end\{minipage\}', '', text, flags=re.DOTALL)
    text = re.sub(r'(?<!\\)%[^\n]*', '', text)
    text = re.sub(r'\\madethi\s*\{([^}]*)\}', r'Mã đề thi: \1\n', text)
    
    # Chuẩn hóa chapter, part, section thành tiêu đề in đậm (xử lý cả ngoặc lồng nhau)
    text = replace_section_titles(text)
    
    # Xóa các lệnh môi trường căn lề và định dạng trang LaTeX thừa trong Word
    text = re.sub(r'\\begin\{(?:center|flushleft|flushright)\}', '', text)
    text = re.sub(r'\\end\{(?:center|flushleft|flushright)\}', '', text)
    text = re.sub(r'\\centering\b', '', text)
    text = re.sub(r'\\(?:hfill|vfill|hfil|vfil|null|relax)\b', '', text)
    text = re.sub(r'\\(?:selectfont|fontsize\{[^}]*\}\{[^}]*\})\b', '', text)
    text = re.sub(r'\\(?:setlength|addtolength)\{[^}]*\}\{[^}]*\}', '', text)
    text = re.sub(r'\\(?:setcounter|addtocounter)\{[^}]*\}\{[^}]*\}', '', text)
    
    text = re.sub(r'\\par\b', '\n', text)
    text = re.sub(r'\\noindent\b', '', text)
    return text.strip()


def replace_section_titles(text: str) -> str:
    """Chuyển đổi \\chapter, \\part, \\section... thành \\textbf{...} an toàn kể cả khi có ngoặc lồng."""
    res = ''
    i = 0
    while i < len(text):
        m = re.match(r'\\(?:part|chapter|(?:sub)*section)\*?(?:\s*\[[^\]]*\])?\s*\{', text[i:])
        if m:
            i += m.end()
            bc = 1
            si = i
            while i < len(text) and bc > 0:
                if text[i] == '{' and text[i-1] != '\\': bc += 1
                elif text[i] == '}' and text[i-1] != '\\': bc -= 1
                i += 1
            arg = text[si:i-1].strip()
            res += f'\n\n\\textbf{{{arg}}}\n\n'
        else:
            res += text[i]
            i += 1
    return res


def break_immini(text: str) -> str:
    """Tách môi trường \\immini{text}{hình} thành các đoạn nối tiếp."""
    res = ''
    idx = 0
    while idx < len(text):
        m = re.match(r'\\imminiL?(?:\[.*?\])?\s*', text[idx:])
        if m:
            idx += m.end()
            while idx < len(text) and text[idx].isspace(): idx += 1
            if idx < len(text) and text[idx] == '{':
                s1 = idx; bc = 1; idx += 1
                while idx < len(text) and bc > 0:
                    if text[idx] == '{' and text[idx-1] != '\\': bc += 1
                    elif text[idx] == '}' and text[idx-1] != '\\': bc -= 1
                    idx += 1
                arg1 = text[s1+1:idx-1]
            else: arg1 = ''
            while idx < len(text) and text[idx].isspace(): idx += 1
            if idx < len(text) and text[idx] == '{':
                s2 = idx; bc = 1; idx += 1
                while idx < len(text) and bc > 0:
                    if text[idx] == '{' and text[idx-1] != '\\': bc += 1
                    elif text[idx] == '}' and text[idx-1] != '\\': bc -= 1
                    idx += 1
                arg2 = text[s2+1:idx-1]
            else: arg2 = ''
            res += f'{arg1}\n\n{arg2}\n\n'
        else:
            res += text[idx]
            idx += 1
    return res


def replace_math_systems(text: str) -> str:
    """Thay thế \\heva và \\hoac sang hệ/tuyển LaTeX chuẩn."""
    res = ''; i = 0
    while i < len(text):
        m = re.match(r'\\(heva|hoac)\s*\{', text[i:])
        if m:
            cmd = m.group(1); i += m.end(); bc = 1; si = i
            while i < len(text) and bc > 0:
                if text[i] == '{' and text[i-1] != '\\': bc += 1
                elif text[i] == '}' and text[i-1] != '\\': bc -= 1
                i += 1
            if bc == 0:
                inner = replace_math_systems(text[si:i-1]).replace('&', '')
                if cmd == 'heva': res += f'\\begin{{cases}}{inner}\\end{{cases}}'
                else: res += f'\\left[\\begin{{array}}{{l}}{inner}\\end{{array}}\\right.'
            else: res += '\\' + cmd + '{'
        else: res += text[i]; i += 1
    return res


def format_solutions(code: str) -> str:
    """Định dạng các khối lời giải thành \\textbf{Lời giải:} rõ ràng."""
    res = ''; i = 0
    while i < len(code):
        m = re.match(r'\\loigiai\s*\{', code[i:])
        if m:
            res += '\n\n\\textbf{Lời giải:}\n\n'
            i += m.end(); bc = 1
            sc = i
            while i < len(code) and bc > 0:
                if code[i] == '{' and code[i-1] != '\\': bc += 1
                elif code[i] == '}' and code[i-1] != '\\': bc -= 1
                i += 1
            res += code[sc:i-1] + '\n\n'
        else:
            res += code[i]; i += 1
    return res


def remove_solutions(code: str) -> str:
    """Loại bỏ hoàn toàn các khối lời giải khi chỉ cần xuất Đề bài."""
    code = re.sub(r'\\begin\{loigiai\}.*?\\end\{loigiai\}', '', code, flags=re.DOTALL)
    res = ''; i = 0
    while i < len(code):
        m = re.match(r'\\loigiai\s*\{', code[i:])
        if m:
            i += m.end(); bc = 1
            while i < len(code) and bc > 0:
                if code[i] == '{' and code[i-1] != '\\': bc += 1
                elif code[i] == '}' and code[i-1] != '\\': bc -= 1
                i += 1
        else:
            res += code[i]; i += 1
    return res


def replace_shortans_commands(text: str, current_mode: str) -> str:
    """Định dạng lệnh \\shortans thành Đáp số."""
    res = ''; i = 0
    while i < len(text):
        m = re.match(r'\\shortans(?:\s*\[.*?\])?\s*\{', text[i:])
        if m:
            i += m.end(); bc = 1; sc = i
            while i < len(text) and bc > 0:
                if text[i] == '{' and (i == 0 or text[i-1] != '\\'): bc += 1
                elif text[i] == '}' and (i == 0 or text[i-1] != '\\'): bc -= 1
                i += 1
            arg = text[sc:i-1].strip() if bc == 0 else ''
            if current_mode != 'questions':
                res += f'\n\n\\textbf{{Đáp số:}} {arg}\n\n'
        else:
            res += text[i]
            i += 1
    res = re.sub(r'\\shortans\b(?:\s*\[.*?\])?', '', res)
    return res


def replace_double_slash(text: str) -> str:
    """Thay thế dấu \\\\ thành xuống dòng (ngoài phạm vi công thức)."""
    parts = re.split(r'(\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|\$[^\$]+?\$)', text)
    res = ''
    for part in parts:
        if part.startswith('$') or part.startswith(r'\[') or part.startswith(r'\('):
            res += part
        else:
            part = re.sub(r'\\\\(?:\s*\[[^\]]*\])?(\s*\\(?:loigiai|choice|choiceTF|begin\{loigiai\}|begin\{center\}))', r'\1', part)
            part = re.sub(r'\\\\', '\n\n', part)
            res += part
    return res


def replace_ex_and_lists(text: str) -> str:
    """Chuẩn hóa các môi trường câu hỏi ex, bt, vd, listEX..."""
    q_count = 0
    def rep_ex(m):
        nonlocal q_count; q_count += 1
        return f"\n\n\\textbf{{Câu {q_count}.}} "
    text = re.sub(r'\\begin\{(ex|bt|vd|bai|cau)\}(\[.*?\])?\s*', rep_ex, text)
    text = re.sub(r'\\end\{(ex|bt|vd|bai|cau)\}', r'\n', text)
    text = re.sub(r'\\begin\{enumEX\}\[.*?\]\{.*?\}', r'\n', text)
    text = re.sub(r'\\begin\{enumEX\}\{.*?\}', r'\n', text)
    text = re.sub(r'\\end\{enumEX\}', r'\n', text)
    text = re.sub(r'\\begin\{listEX\}.*?', r'\n', text)
    text = re.sub(r'\\end\{listEX\}', r'\n', text)
    text = re.sub(r'\\begin\{itemchoice\}.*?', r'\n', text)
    text = re.sub(r'\\end\{itemchoice\}', r'\n', text)
    text = re.sub(r'\\itemch\b', r'\\item', text)
    text = re.sub(r'\\begin\{enumerate\}(\[.*?\])?', r'\n', text)
    text = re.sub(r'\\end\{enumerate\}', r'\n', text)
    text = re.sub(r'\\begin\{itemize\}', r'\n', text)
    text = re.sub(r'\\end\{itemize\}', r'\n', text)
    text = re.sub(r'\\item\s+', r'\n- ', text)
    text = re.sub(r'(\\textbf\{C(?:â|a)u\s+\d+[\.:]?\})\s+', r'\1 ', text)
    return text


def clean_true_commands(text: str, current_mode: str) -> str:
    """
    Xử lý triệt để lệnh \\True ngoài khối \\choice:
    - Nếu là 'questions': Xóa sạch \\True để học sinh không thấy đáp án.
    - Nếu là 'full': Gạch chân chữ cái phương án tương ứng và xóa \\True.
    """
    if current_mode == 'questions':
        text = re.sub(r'\\(?:True|TRUE|true)\b[\s~]*', '', text)
    else:
        # 1. \textbf{A.} \True hoặc \textbf{A.}~\True
        text = re.sub(r'\\textbf\{([ABCDabcd]\.|\([ABCDabcd]\))\}[\s~]*\\(?:True|TRUE|true)\b[\s~]*', r'\\underline{\\textbf{\1}} ', text)
        # 2. A. \True hoặc (A) \True hoặc A.~\True
        text = re.sub(r'(?<![a-zA-Z0-9])([ABCDabcd]\.|\([ABCDabcd]\))[\s~]*\\(?:True|TRUE|true)\b[\s~]*', r'\\underline{\\textbf{\1}} ', text)
        # 3. \True \textbf{A.} hoặc \True A.
        text = re.sub(r'\\(?:True|TRUE|true)\b[\s~]*\\textbf\{([ABCDabcd]\.|\([ABCDabcd]\))\}[\s~]*', r'\\underline{\\textbf{\1}} ', text)
        text = re.sub(r'\\(?:True|TRUE|true)\b[\s~]*([ABCDabcd]\.|\([ABCDabcd]\))[\s~]*', r'\\underline{\\textbf{\1}} ', text)
        # 4. Xóa sạch mọi \True còn sót lại
        text = re.sub(r'\\(?:True|TRUE|true)\b[\s~]*', '', text)
    return text


def replace_choice_commands(text: str, current_mode: str, word_standard: str = 'btn_group') -> str:
    """
    Chuẩn hóa phương án A, B, C, D:
    Xử lý triệt để \\True, phân chia 4 cột (§), 2 cột (¨) hoặc 1 dòng riêng lẻ (\n).
    """
    std = WORD_STANDARDS.get(word_standard, WORD_STANDARDS['btn_group'])
    chia1 = std['chia1']
    chia2 = std['chia2']
    result = ''; i = 0
    while i < len(text):
        mc = re.match(r'\\choice(TF)?(?![a-zA-Z])', text[i:])
        if mc:
            is_tf = bool(mc.group(1)); si = i; i += mc.end()
            while i < len(text) and (text[i].isspace() or not text[i].isprintable()): i += 1
            if i < len(text) and text[i] == '[':
                while i < len(text) and text[i] != ']': i += 1
                i += 1
            choices = []
            for _ in range(4):
                while i < len(text) and (text[i].isspace() or not text[i].isprintable()): i += 1
                if i >= len(text) or text[i] != '{': break
                si_c = i; bc = 1; i += 1
                while i < len(text) and bc > 0:
                    if text[i] == '{' and text[i-1] != '\\': bc += 1
                    elif text[i] == '}' and text[i-1] != '\\': bc -= 1
                    i += 1
                if bc == 0:
                    choices.append(text[si_c+1:i-1].strip())
            if len(choices) == 4:
                prefix = ['a)', 'b)', 'c)', 'd)'] if is_tf else ['A.', 'B.', 'C.', 'D.']
                labels = []; contents = []
                for idx, c in enumerate(choices):
                    is_true = False
                    # Phát hiện mọi dạng \True
                    if re.search(r'\\(?:True|TRUE|true)\b', c) or c.startswith('True') or c.startswith('*'):
                        is_true = True
                        c = re.sub(r'\\(?:True|TRUE|true)\b[\s~]*', '', c).strip()
                        c = re.sub(r'^True[\s~]*', '', c).strip()
                        c = re.sub(r'^\*[\s~]*', '', c).strip()
                    # Xóa các nhãn A. thừa nếu có
                    c = re.sub(r'^(?:[ABCD]\.|\([ABCD]\)|[abcd]\)|\([abcd]\))[\s~]*', '', c).strip()
                    # Xóa dấu chấm phẩy thừa cuối phương án
                    c = re.sub(r'[\.,;:]\s*$', '', c).strip()
                    c = re.sub(r'[\.,;:]\s*\$$', '$', c).strip()

                    if is_true:
                        labels.append(f'\\textbf{{{prefix[idx]}}}' if current_mode == 'questions' else f'\\underline{{\\textbf{{{prefix[idx]}}}}}')
                    else:
                        labels.append(f'\\textbf{{{prefix[idx]}}}')
                    contents.append(c)

                def ct(t): return re.sub(r'\\[a-zA-Z]+', '', t)
                ml = max(len(ct(c)) for c in contents)
                if not is_tf:
                    if ml <= chia1:
                        fc = f'\n\n{labels[0]} {contents[0]}\u00a7{labels[1]} {contents[1]}\u00a7{labels[2]} {contents[2]}\u00a7{labels[3]} {contents[3]}\n\n'
                    elif ml <= chia2:
                        fc = f'\n\n{labels[0]} {contents[0]}\u00a8{labels[1]} {contents[1]}\n\n{labels[2]} {contents[2]}\u00a8{labels[3]} {contents[3]}\n\n'
                    else:
                        fc = f'\n\n{labels[0]} {contents[0]}\n\n{labels[1]} {contents[1]}\n\n{labels[2]} {contents[2]}\n\n{labels[3]} {contents[3]}\n\n'
                else:
                    fc = '\n\n'
                    for idx in range(4):
                        fc += f'{labels[idx]} {contents[idx]}\n\n'

                # Kéo ảnh TiKZ lên trên đáp án nếu có
                peek = text[i:]
                mi = re.match(r'^(?:[\s\n\r]*|\\par\s*|\\noindent\s*|\\vspace\{[^}]*\}\s*|\\begin\{center\}\s*|\\centering\s*)*(\[\[TIKZ_IMG_\d+\]\])(?:\s*\\end\{center\})?', peek)
                if mi:
                    fc = f'\n\n{mi.group(1)}\n\n' + fc
                    i += mi.end()

                result += fc + '\n\n'
            else:
                result += text[si:i]
        else:
            result += text[i]
            i += 1
    return result


def _apply_inline_formatting(paragraph, text: str, temp_img_dir: str = "", input_dir: str = ""):
    """Phân giải các thẻ in đậm, in nghiêng, gạch chân và hình ảnh inline vào Paragraph của python-docx."""
    FN = 'Times New Roman'
    FS = Pt(12)
    
    tokens = re.split(
        r'(\\includegraphics(?:\[.*?\])?\{[^}]+\}|'
        r'\\underline\{\\textbf\{[^{}]*\}\}|'
        r'\\textbf\{\\underline\{[^{}]*\}\}|'
        r'\\textbf\{[^{}]*\}|'
        r'\\textit\{[^{}]*\}|'
        r'\\underline\{[^{}]*\}|'
        r'\$\$.*?\$\$|'
        r'\$[^\$]+?\$|'
        r'\\\[.*?\\\]|'
        r'\\\(.*?\\\))',
        text
    )
    for tok in tokens:
        if not tok: continue
        
        # Thẻ chèn hình ảnh \includegraphics{...}
        m_img = re.match(r'\\includegraphics(?:\[.*?\])?\{([^}]+)\}', tok)
        if m_img:
            fp_raw = m_img.group(1).strip()
            fp = fp_raw
            # Kiểm tra ảnh trong temp_img_dir hoặc /home/pyodide/images
            search_dirs = [d for d in [temp_img_dir, input_dir, "/home/pyodide/images"] if d and os.path.exists(d)]
            if not os.path.isabs(fp) or not os.path.exists(fp):
                base_name = os.path.basename(fp)
                found = False
                for sdir in search_dirs:
                    for cand in [fp, base_name]:
                        cand_path = os.path.join(sdir, cand)
                        if os.path.exists(cand_path):
                            fp = cand_path; found = True; break
                        for ext_try in ['.png', '.jpg', '.jpeg', '.wmf', '.emf']:
                            if os.path.exists(cand_path + ext_try):
                                fp = cand_path + ext_try; found = True; break
                        if found: break
                    if found: break
            if os.path.exists(fp):
                try:
                    from PIL import Image
                    with Image.open(fp) as _im:
                        _w_px, _h_px = _im.size
                    wi = _w_px / 300.0; hi = _h_px / 300.0
                    # Thu nhỏ ~40% theo yêu cầu để ảnh không bị quá khổ trong Word
                    mw, mh = 1.7, 1.3; sc = 1.0
                    if wi > mw: sc = mw / wi
                    if hi * sc > mh: sc = min(sc, mh / hi)
                    paragraph.add_run().add_picture(fp, width=Inches(max(0.4, wi * sc)))
                except Exception:
                    try: paragraph.add_run().add_picture(fp, width=Inches(1.1))
                    except Exception: pass
            else:
                paragraph.add_run(f"[{fp_raw}]")
            continue

        # Công thức toán (giữ nguyên để MathType processor chuyển đổi)
        if tok.startswith('$') or tok.startswith(r'\[') or tok.startswith(r'\('):
            r = paragraph.add_run(tok)
            r.font.name = FN; r.font.size = FS
            continue
            
        # In đậm + gạch chân (cả 2 thứ tự)
        m_bu1 = re.match(r'\\underline\{\\textbf\{(.*?)\}\}', tok)
        m_bu2 = re.match(r'\\textbf\{\\underline\{(.*?)\}\}', tok)
        if m_bu1 or m_bu2:
            content = m_bu1.group(1) if m_bu1 else m_bu2.group(1)
            r = paragraph.add_run(content)
            r.font.name = FN; r.font.size = FS; r.bold = True; r.underline = True
            continue
            
        # In đậm
        m_b = re.match(r'\\textbf\{(.*?)\}', tok)
        if m_b:
            r = paragraph.add_run(m_b.group(1))
            r.font.name = FN; r.font.size = FS; r.bold = True
            continue
            
        # In nghiêng
        m_i = re.match(r'\\textit\{(.*?)\}', tok)
        if m_i:
            r = paragraph.add_run(m_i.group(1))
            r.font.name = FN; r.font.size = FS; r.italic = True
            continue
            
        # Gạch chân
        m_u = re.match(r'\\underline\{(.*?)\}', tok)
        if m_u:
            r = paragraph.add_run(m_u.group(1))
            r.font.name = FN; r.font.size = FS; r.underline = True
            continue
            
        # Văn bản thường
        r = paragraph.add_run(tok)
        r.font.name = FN; r.font.size = FS


def compile_tikz_blocks_to_png(tikz_blocks: list, work_dir: str, log_fn=None) -> list:
    """
    Biên dịch các khối TiKZ sang file ảnh PNG phân giải cao (300 DPI) bằng pdflatex + PyMuPDF.
    Trả về danh sách tên file ảnh [tikz_01.png, tikz_02.png, ...]
    """
    if not tikz_blocks:
        return []

    header_single = (
        '\\documentclass[tikz,border=2pt]{standalone}\n'
        '\\usepackage[utf8]{vietnam}\n\\usepackage{amsmath,amssymb}\n'
        '\\usepackage{tkz-euclide,tkz-tab,pgfplots}\n\\pgfplotsset{compat=newest}\n'
        '\\usetikzlibrary{math,through,calc,fadings,intersections,shadings,angles,quotes,shapes,shapes.geometric,arrows,arrows.meta,patterns,snakes,decorations.text,matrix,chains}\n'
        '\\usepackage{qrcode}\n'
        '\\def\\mauphieu{black}\n\\def\\made{0,1,0,1}\n\\def\\labeltext#1{\\textbf{#1}}\n'
        '\\def\\TN{10}\n\\def\\DS{4}\n\\def\\TLN{6}\n'
        '\\begin{document}\n'
    )

    tc = header_single
    for b in tikz_blocks:
        tc += f'{b}\n'
    tc += '\\end{document}'

    all_tex = os.path.join(work_dir, 'all_tikz.tex')
    with open(all_tex, 'w', encoding='utf-8') as f:
        f.write(tc)

    engine_path = shutil.which('pdflatex') or 'pdflatex'
    if log_fn: log_fn(f"Đang render {len(tikz_blocks)} hình vẽ TiKZ bằng {os.path.basename(engine_path)}...")

    # Chạy batch compile
    try:
        subprocess.run(
            [engine_path, '-interaction=nonstopmode', 'all_tikz.tex'],
            cwd=work_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
            timeout=70
        )
        all_pdf = os.path.join(work_dir, 'all_tikz.pdf')
        if os.path.exists(all_pdf):
            try:
                import fitz
                doc = fitz.open(all_pdf)
                for idx in range(len(doc)):
                    pix = doc.load_page(idx).get_pixmap(matrix=fitz.Matrix(3, 3), alpha=False)
                    pix.save(os.path.join(work_dir, f'tikz_{idx+1:02d}.png'))
                doc.close()
            except Exception as e:
                if log_fn: log_fn(f"Lỗi chuyển PDF TiKZ sang ảnh: {e}")
    except Exception as e:
        if log_fn: log_fn(f"TiKZ batch compile warning: {e}")

    # Fallback cho từng block nếu còn thiếu ảnh
    for idx, b in enumerate(tikz_blocks):
        png_path = os.path.join(work_dir, f'tikz_{idx+1:02d}.png')
        if not os.path.exists(png_path):
            single_tex = os.path.join(work_dir, f'single_{idx}.tex')
            with open(single_tex, 'w', encoding='utf-8') as sf:
                sf.write(header_single + b + '\n\\end{document}')
            try:
                subprocess.run(
                    [engine_path, '-interaction=nonstopmode', f'single_{idx}.tex'],
                    cwd=work_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
                    timeout=25
                )
                single_pdf = os.path.join(work_dir, f'single_{idx}.pdf')
                if os.path.exists(single_pdf):
                    import fitz
                    sdoc = fitz.open(single_pdf)
                    if len(sdoc) > 0:
                        spix = sdoc[0].get_pixmap(matrix=fitz.Matrix(3, 3), alpha=False)
                        spix.save(png_path)
                    sdoc.close()
            except Exception:
                pass

    pngs = sorted([f for f in os.listdir(work_dir) if f.startswith('tikz_') and f.endswith('.png')])
    if log_fn: log_fn(f"Đã render thành công {len(pngs)}/{len(tikz_blocks)} ảnh TiKZ.")
    return pngs


def insert_header_table(doc: Document, header_config: dict):
    """
    Chèn Khung Tiêu đề Đề thi (Header) vào trang đầu tiên của file Word:
    - standard_gov: Mẫu 1 Chuẩn Sở / Bộ GD (2 cột chính thức, kèm khung SBD & Mã đề)
    - brand_center: Mẫu 2 Trung tâm / QMath (Trang trọng)
    - compact: Mẫu 3 Tiêu đề Rút gọn (Đơn giản)
    - none: Không tạo tiêu đề
    """
    if not header_config:
        return
    style = header_config.get('style', 'none')
    if style == 'none':
        return

    agency = (header_config.get('agency') or 'SỞ GD&ĐT HÀ NỘI').strip().upper()
    school = (header_config.get('school') or 'TRƯỜNG THPT TRẦN QUANG KHẢI').strip().upper()
    exam_type = (header_config.get('exam_type') or '(ĐỀ CHÍNH THỨC)').strip().upper()
    title = (header_config.get('title') or 'ĐỀ THI').strip().upper()
    subject = (header_config.get('subject') or 'TOÁN HỌC').strip().upper()
    grade = str(header_config.get('grade') or '').strip()
    duration = str(header_config.get('duration') or 90).strip()
    exam_code = str(header_config.get('exam_code') or '1001').strip()
    candidate_info = header_config.get('candidate_info', True)
    total_q = header_config.get('total_questions', 0)
    
    FN = 'Times New Roman'
    
    def _add_p_run(p, text, bold=False, italic=False, underline=False, size_pt=11, color=None, space_after=2):
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(space_after)
        p.paragraph_format.line_spacing = 1.0
        r = p.add_run(text)
        r.font.name = FN
        r.font.size = Pt(size_pt)
        r.bold = bold
        r.italic = italic
        r.underline = underline
        if color:
            r.font.color.rgb = RGBColor(*color)
        return r

    if style == 'standard_gov':
        # Mẫu 1: Chuẩn Sở / Bộ GD (Bảng 2 cột không viền)
        tbl = doc.add_table(rows=1, cols=2)
        try: tbl.style = 'Normal Table'
        except Exception: pass
        tbl.autofit = False
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        
        c_left = tbl.cell(0, 0)
        c_right = tbl.cell(0, 1)
        c_left.width = Cm(7.2)
        c_right.width = Cm(10.8)
        
        for cell in (c_left, c_right):
            tcPr = cell._tc.get_or_add_tcPr()
            tcB = OxmlElement('w:tcBorders')
            for b_name in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
                b = OxmlElement(f'w:{b_name}')
                b.set(qn('w:val'), 'none')
                tcB.append(b)
            tcPr.append(tcB)
            
        # Cột 1 trái
        p1 = c_left.paragraphs[0]
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p1, agency, bold=True, size_pt=11, space_after=1)
        
        p2 = c_left.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p2, school, bold=True, underline=True, size_pt=11, space_after=2)
        
        p3 = c_left.add_paragraph()
        p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p3, exam_type, bold=True, size_pt=11, space_after=1)
        
        sub_desc = f"(Đề thi có {total_q} câu hỏi)" if total_q else "(Đề thi gồm có 04 trang)"
        p4 = c_left.add_paragraph()
        p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p4, sub_desc, italic=True, size_pt=10, space_after=2)
        
        # Cột 2 phải
        pr1 = c_right.paragraphs[0]
        pr1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(pr1, title, bold=True, size_pt=11, space_after=1)
        
        pr2 = c_right.add_paragraph()
        pr2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        mon_str = f"MÔN THI: {subject}" + (f" - KHỐI {grade}" if grade else "")
        _add_p_run(pr2, mon_str, bold=True, size_pt=11, space_after=1)
        
        pr3 = c_right.add_paragraph()
        pr3.alignment = WD_ALIGN_PARAGRAPH.CENTER
        time_str = f"Thời gian làm bài: {duration} phút, không kể thời gian phát đề"
        _add_p_run(pr3, time_str, italic=True, underline=True, size_pt=10, space_after=2)

    elif style == 'brand_center':
        # Mẫu 2: Trung tâm / QMath (Trang trọng)
        p1 = doc.add_paragraph()
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p1, school, bold=True, size_pt=13, color=(30, 64, 175), space_after=2)
        
        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p2, title, bold=True, size_pt=14, space_after=3)
        
        p3 = doc.add_paragraph()
        p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
        info_parts = [f"Môn: {subject}"]
        if grade: info_parts.append(f"Khối {grade}")
        info_parts.append(f"Thời gian: {duration} phút")
        if exam_code: info_parts.append(f"Mã đề: {exam_code}")
        _add_p_run(p3, " | ".join(info_parts), italic=True, size_pt=11, space_after=4)

    elif style == 'compact':
        # Mẫu 3: Tiêu đề Rút gọn
        p1 = doc.add_paragraph()
        p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(p1, title, bold=True, size_pt=13, space_after=2)
        
        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        info_str = f"Môn: {subject} - Thời gian: {duration} phút" + (f" - Mã đề: {exam_code}" if exam_code else "")
        _add_p_run(p2, info_str, italic=True, size_pt=11, space_after=4)

    # Khung Họ tên thí sinh, SBD & Mã đề thi (nếu candidate_info == True)
    if candidate_info:
        tbl_info = doc.add_table(rows=1, cols=2)
        try: tbl_info.style = 'Normal Table'
        except Exception: pass
        tbl_info.alignment = WD_TABLE_ALIGNMENT.CENTER
        
        ci_left = tbl_info.cell(0, 0)
        ci_right = tbl_info.cell(0, 1)
        ci_left.width = Cm(13.2)
        ci_right.width = Cm(4.8)
        
        # Ô trái: Bỏ viền
        tcPr_l = ci_left._tc.get_or_add_tcPr()
        tcB_l = OxmlElement('w:tcBorders')
        for b_name in ('top', 'left', 'bottom', 'right'):
            b = OxmlElement(f'w:{b_name}'); b.set(qn('w:val'), 'none'); tcB_l.append(b)
        tcPr_l.append(tcB_l)
        ci_left.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        
        pi = ci_left.paragraphs[0]
        pi.alignment = WD_ALIGN_PARAGRAPH.LEFT
        _add_p_run(pi, "Họ và tên thí sinh: .................................................... Số báo danh: ................", bold=True, size_pt=11, space_after=2)
        
        # Ô phải: Đóng khung viền đen nổi bật cho Mã đề thi
        tcPr_r = ci_right._tc.get_or_add_tcPr()
        tcB_r = OxmlElement('w:tcBorders')
        for b_name in ('top', 'left', 'bottom', 'right'):
            b = OxmlElement(f'w:{b_name}')
            b.set(qn('w:val'), 'single')
            b.set(qn('w:sz'), '8')
            b.set(qn('w:space'), '0')
            b.set(qn('w:color'), '000000')
            tcB_r.append(b)
        tcPr_r.append(tcB_r)
        ci_right.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        
        pr_code = ci_right.paragraphs[0]
        pr_code.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_p_run(pr_code, f"Mã đề thi {exam_code}", bold=True, size_pt=12, space_after=0)

    # Đoạn đệm cách giữa Tiêu đề và nội dung Câu 1
    sp_head = doc.add_paragraph()
    sp_head.paragraph_format.space_before = Pt(0)
    sp_head.paragraph_format.space_after = Pt(6)


def build_blank_skeleton_docx(processed_text: str,
                              word_standard: str = 'btn_group',
                              temp_img_dir: str = "",
                              tabular_blocks: list = None,
                              custom_margins=None,
                              input_dir: str = "",
                              header_config: dict = None) -> Document:
    """
    Tạo file Word chuẩn hóa (Tùy chọn Khung tiêu đề Header chuẩn Sở/Trường/QMath).
    Tự động chèn hình vẽ TiKZ, bảng biểu Tabular/Longtable, ảnh Includegraphics.
    """
    doc = Document()
    FN = 'Times New Roman'
    FS = Pt(12)
    
    std = WORD_STANDARDS.get(word_standard, WORD_STANDARDS['btn_group'])
    m_left, m_right, m_top, m_bottom = custom_margins if custom_margins else std['margins']
    
    # Thiết lập trang in hoàn toàn sạch sẽ
    for sec in doc.sections:
        sec.page_width = Cm(21.0)
        sec.page_height = Cm(29.7)
        sec.left_margin = Cm(m_left)
        sec.right_margin = Cm(m_right)
        sec.top_margin = Cm(m_top)
        sec.bottom_margin = Cm(m_bottom)
        sec.header_distance = Cm(0.6)
        sec.footer_distance = Cm(0.6)
        
        # ĐẢM BẢO KHÔNG CÓ HEADER & FOOTER MẶC ĐỊNH
        sec.header.is_linked_to_previous = False
        for p in list(sec.header.paragraphs): p.text = ""
        sec.footer.is_linked_to_previous = False
        for p in list(sec.footer.paragraphs): p.text = ""

    # Chèn Khung tiêu đề đề thi nếu có cấu hình
    if header_config:
        insert_header_table(doc, header_config)

    def set_cell_borders(cell, color='000000', sz='4', val='single'):
        tcPr = cell._tc.get_or_add_tcPr()
        tcB = tcPr.find(qn('w:tcBorders'))
        if tcB is None:
            tcB = OxmlElement('w:tcBorders')
            tcPr.append(tcB)
        else:
            tcB.clear()
        for e in ('top', 'left', 'bottom', 'right'):
            b = OxmlElement(f'w:{e}')
            b.set(qn('w:val'), val)
            b.set(qn('w:sz'), sz)
            b.set(qn('w:space'), '0')
            b.set(qn('w:color'), color)
            tcB.append(b)

    def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
        tcPr = cell._tc.get_or_add_tcPr()
        tcMar = tcPr.find(qn('w:tcMar'))
        if tcMar is None:
            tcMar = OxmlElement('w:tcMar')
            tcPr.append(tcMar)
        else:
            tcMar.clear()
        for m, val in (('top', top), ('bottom', bottom), ('left', left), ('right', right)):
            node = OxmlElement(f'w:{m}')
            node.set(qn('w:w'), str(val))
            node.set(qn('w:type'), 'dxa')
            tcMar.append(node)

    def format_para(paragraph, text):
        _apply_inline_formatting(paragraph, text, temp_img_dir=temp_img_dir, input_dir=input_dir)

    # Tự động trích xuất bảng biểu tabular / longtable nếu chưa được trích xuất từ trước
    if tabular_blocks is None:
        tabular_blocks = []
        def _auto_extract_tab(m):
            idx = len(tabular_blocks)
            tabular_blocks.append(m.group(0))
            return f"\n\n[[TABULAR_{idx}]]\n\n"
        table_pattern = re.compile(r'\\begin\{(?:tabular\*?|longtable)\}.*?\\end\{(?:tabular\*?|longtable)\}', re.DOTALL)
        processed_text = table_pattern.sub(_auto_extract_tab, processed_text)

    paras = [p.strip() for p in processed_text.split('\n') if p.strip()]
    roman = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']
    phan = 1
    
    for raw_para in paras:
        tl = raw_para.lower()
        
        # 1. BẢNG BIỂU TABULAR & LONGTABLE
        tbm = re.search(r'\[\[TABULAR_(\d+)\]\]', raw_para)
        if tbm:
            ti = int(tbm.group(1))
            ct = raw_para.replace(tbm.group(0), '').strip()
            if ct:
                p = doc.add_paragraph()
                format_para(p, ct)
            if tabular_blocks and ti < len(tabular_blocks):
                tb_text = tabular_blocks[ti]
                # Hỗ trợ tabular* có {width}{col_spec} và tabular/longtable có {col_spec}
                m = re.search(r'\\begin\{tabular\*\}\s*(?:\[[^\]]*\])?\s*\{[^}]*\}\s*\{([^}]*)\}(.*?)\\end\{tabular\*\}', tb_text, re.DOTALL)
                if not m:
                    m = re.search(r'\\begin\{(?:tabular|longtable)\}\s*(?:\[[^\]]*\])?\s*\{([^}]*)\}(.*?)\\end\{(?:tabular|longtable)\}', tb_text, re.DOTALL)
                if not m:
                    m = re.search(r'\\begin\{(?:tabular\*?|longtable)\}.*?\{([^}]*)\}(.*?)\\end\{(?:tabular\*?|longtable)\}', tb_text, re.DOTALL)
                if m:
                    col_spec = m.group(1)
                    content = m.group(2)
                    
                    # Tự động chuẩn hóa lỗi người dùng quên gõ '\\' trước \hline (cả khi cùng dòng hoặc xuống dòng)
                    content = re.sub(r'([^\n\\])\s*\n\s*\\hline', r'\1 \\\\\n\\hline', content)
                    content = re.sub(r'([^\n\\])\s*\\hline', r'\1 \\\\\n\\hline', content)
                    
                    # Mở rộng các cú pháp lặp *{n}{...} trong col_spec
                    col_spec_exp = re.sub(r'\*\{(\d+)\}\{([^}]+)\}', lambda match: match.group(2) * int(match.group(1)), col_spec)
                    col_aligns = [c.lower() for c in col_spec_exp if c.lower() in ('l', 'c', 'r', 'p', 'm', 'b')]
                    
                    rows = re.split(r'\\\\(?:\s*\[[^\]]*\])?', content)
                    parsed_rows = []
                    for row in rows:
                        row = re.sub(r'\\(hline|toprule|midrule|bottomrule)', '', row)
                        row = re.sub(r'\\cline\{[^}]*\}', '', row).strip()
                        if not row:
                            continue
                        cells = [c.strip() for c in row.split('&')]
                        parsed_rows.append(cells)
                    
                    if parsed_rows:
                        num_cols = max(len(r) for r in parsed_rows)
                        tt = doc.add_table(rows=len(parsed_rows), cols=num_cols)
                        try:
                            tt.style = 'Table Grid'
                        except Exception:
                            pass
                        tt.autofit = True
                        tt.alignment = WD_TABLE_ALIGNMENT.CENTER
                        
                        for ri, pr in enumerate(parsed_rows):
                            for ci in range(num_cols):
                                cell = tt.cell(ri, ci)
                                set_cell_borders(cell)
                                set_cell_margins(cell)
                                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                                
                                pc = pr[ci] if ci < len(pr) else ''
                                # Xử lý \multicolumn{n}{align}{content}
                                m_mc = re.match(r'\\multicolumn\{\d+\}\{[^}]*\}\{(.*?)\}', pc)
                                if m_mc:
                                    pc = m_mc.group(1)
                                pc = re.sub(r'\\(hline|toprule|midrule|bottomrule)', '', pc).strip()
                                pc = re.sub(r'\\cline\{[^}]*\}', '', pc).strip()
                                pc = pc.replace(r'\newline', '\n').replace(r'\break', '\n')
                                
                                # Xác định căn lề ô (l, c, r)
                                align_char = col_aligns[ci] if ci < len(col_aligns) else ('l' if ci == 0 else 'c')
                                cell_align = WD_ALIGN_PARAGRAPH.CENTER
                                if align_char in ('l', 'p'):
                                    cell_align = WD_ALIGN_PARAGRAPH.LEFT
                                elif align_char == 'r':
                                    cell_align = WD_ALIGN_PARAGRAPH.RIGHT
                                
                                sub_lines = [sl.strip() for sl in pc.split('\n') if sl.strip()]
                                if not sub_lines:
                                    sub_lines = ['']
                                for sli, sline in enumerate(sub_lines):
                                    cp = cell.paragraphs[0] if sli == 0 else cell.add_paragraph()
                                    cp.alignment = cell_align
                                    cp.paragraph_format.space_before = Pt(2)
                                    cp.paragraph_format.space_after = Pt(2)
                                    cp.paragraph_format.line_spacing = 1.0
                                    format_para(cp, sline)
                                    
                        sp = doc.add_paragraph()
                        sp.paragraph_format.space_before = Pt(0)
                        sp.paragraph_format.space_after = Pt(4)
            continue

        # 2. HÌNH VẼ TIKZ ĐÃ RENDER SANG PNG
        all_tms = list(re.finditer(r'\[\[TIKZ_IMG_(\d+)\]\]', raw_para))
        if all_tms:
            curr_pos = 0
            for tm in all_tms:
                text_before = raw_para[curr_pos:tm.start()].strip()
                if text_before:
                    p = doc.add_paragraph()
                    format_para(p, text_before)
                ti = int(tm.group(1))
                ip = doc.add_paragraph()
                ip.alignment = WD_ALIGN_PARAGRAPH.CENTER
                fp = os.path.join(temp_img_dir, f'tikz_{ti:02d}.png') if temp_img_dir else ""
                if fp and os.path.exists(fp):
                    try:
                        from PIL import Image
                        with Image.open(fp) as _im:
                            _w_px, _h_px = _im.size
                        wi = _w_px / 300.0; hi = _h_px / 300.0
                        # Thu nhỏ ~40% theo yêu cầu
                        mw, mh = 3.1, 2.4; sc = 1.0
                        if wi > mw: sc = mw / wi
                        if hi * sc > mh: sc = min(sc, mh / hi)
                        ip.add_run().add_picture(fp, width=Inches(max(0.8, wi * sc)))
                    except Exception:
                        try: ip.add_run().add_picture(fp, width=Inches(1.8))
                        except Exception: pass
                curr_pos = tm.end()
            text_after = raw_para[curr_pos:].strip()
            if text_after:
                p = doc.add_paragraph()
                format_para(p, text_after)
            continue

        # 3. ẢNH INCLUDERAPHICS NGOÀI
        img_m = re.search(r'\\includegraphics(?:\[.*?\])?\s*\{([^}]+)\}', raw_para)
        if img_m:
            fp_raw = img_m.group(1).strip()
            ct = raw_para.replace(img_m.group(0), '').strip()
            if ct:
                p = doc.add_paragraph()
                format_para(p, ct)
            ip = doc.add_paragraph()
            ip.alignment = WD_ALIGN_PARAGRAPH.CENTER
            fp = fp_raw
            search_dirs = [d for d in [temp_img_dir, input_dir, "/home/pyodide/images"] if d and os.path.exists(d)]
            if not os.path.isabs(fp) or not os.path.exists(fp):
                base_name = os.path.basename(fp)
                found = False
                for sdir in search_dirs:
                    for cand in [fp, base_name]:
                        cand_path = os.path.join(sdir, cand)
                        if os.path.exists(cand_path):
                            fp = cand_path; found = True; break
                        for ext_try in ['.png', '.jpg', '.jpeg', '.wmf', '.emf']:
                            if os.path.exists(cand_path + ext_try):
                                fp = cand_path + ext_try; found = True; break
                        if found: break
                    if found: break
            if os.path.exists(fp):
                try:
                    from PIL import Image
                    with Image.open(fp) as _im:
                        _w_px, _h_px = _im.size
                    wi = _w_px / 300.0; hi = _h_px / 300.0
                    # Thu nhỏ ~40% theo yêu cầu
                    mw, mh = 3.1, 2.4; sc = 1.0
                    if wi > mw: sc = mw / wi
                    if hi * sc > mh: sc = min(sc, mh / hi)
                    ip.add_run().add_picture(fp, width=Inches(max(0.8, wi * sc)))
                except Exception:
                    try: ip.add_run().add_picture(fp, width=Inches(1.8))
                    except Exception: pass
            else:
                ip.add_run(f"[Hình ảnh: {fp_raw}]")
            continue

        # 4. TIÊU ĐỀ CÁC PHẦN THI
        if 'câu trắc nghiệm nhiều phương án' in tl or 'câu trắc nghiệm có nhiều phương án' in tl or (tl.startswith('phần') and 'nhiều phương án' in tl):
            p = doc.add_paragraph()
            r1 = p.add_run(f'PHẦN {roman[phan-1]}. CÂU TRẮC NGHIỆM NHIỀU PHƯƠNG ÁN LỰA CHỌN\n')
            r1.font.name = FN; r1.font.size = Pt(13); r1.bold = True
            r2 = p.add_run('Thí sinh trả lời từ câu 1 đến câu 12. Mỗi câu hỏi thí sinh chỉ chọn một phương án.')
            r2.font.name = FN; r2.font.size = FS; r2.italic = True
            phan += 1
            continue
            
        if 'câu trắc nghiệm đúng sai' in tl or (tl.startswith('phần') and 'đúng sai' in tl):
            p = doc.add_paragraph()
            r1 = p.add_run(f'PHẦN {roman[phan-1]}. CÂU TRẮC NGHIỆM ĐÚNG SAI\n')
            r1.font.name = FN; r1.font.size = Pt(13); r1.bold = True
            r2 = p.add_run('Thí sinh trả lời từ câu 1 đến câu 4. Trong mỗi ý a), b), c), d) ở mỗi câu, thí sinh chọn đúng hoặc sai.')
            r2.font.name = FN; r2.font.size = FS; r2.italic = True
            phan += 1
            continue
            
        if 'câu trắc nghiệm trả lời ngắn' in tl or (tl.startswith('phần') and 'trả lời ngắn' in tl):
            p = doc.add_paragraph()
            r1 = p.add_run(f'PHẦN {roman[phan-1]}. CÂU TRẮC NGHIỆM TRẢ LỜI NGẮN\n')
            r1.font.name = FN; r1.font.size = Pt(13); r1.bold = True
            r2 = p.add_run('Thí sinh trả lời từ câu 1 đến câu 6.')
            r2.font.name = FN; r2.font.size = FS; r2.italic = True
            phan += 1
            continue

        # 5. ĐOẠN CÂU HỎI: Câu 1., Bài 1., Ví dụ 1...
        if re.match(r'^(?:\[[^\]]+\]\s*)?\\textbf\{(?:C(?:â|a)u|B(?:à|a)i|V(?:í|i)\s*d(?:ụ|u))\s+\d+[\.:]?\}', raw_para) or re.match(r'^(?:\[[^\]]+\]\s*)?(?:C(?:â|a)u|B(?:à|a)i|V(?:í|i)\s*d(?:ụ|u))\s+\d+[\.:]', raw_para):
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.left_indent = Cm(std['q_indent'][0])
            pf.first_line_indent = Cm(std['q_indent'][1])
            pf.space_before = Pt(3)
            pf.space_after = Pt(2)
            pf.line_spacing = 1.15
            pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            format_para(p, raw_para)
            continue

        # Tiêu đề chuyên đề / bài học độc lập (\textbf{...})
        if re.match(r'^\\textbf\{[^}]+\}$', raw_para):
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.space_before = Pt(8)
            pf.space_after = Pt(4)
            pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
            format_para(p, raw_para)
            continue

        # 6. PHƯƠNG ÁN 4 CỘT (§)
        if '\u00a7' in raw_para:
            parts = raw_para.split('\u00a7')
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.left_indent = Cm(std['c_indent'][0])
            pf.first_line_indent = Cm(std['c_indent'][1])
            pf.space_before = Pt(0)
            pf.space_after = Pt(2)
            pf.line_spacing = 1.15
            pf.tab_stops.clear_all()
            for t in std['tabs_4col']:
                pf.tab_stops.add_tab_stop(Cm(t), WD_TAB_ALIGNMENT.LEFT)
            for k, part in enumerate(parts):
                if k > 0:
                    tr = p.add_run('\t')
                    tr.font.name = FN; tr.font.size = FS
                format_para(p, part.strip())
            continue

        # 7. PHƯƠNG ÁN 2 CỘT (¨)
        if '\u00a8' in raw_para:
            parts = raw_para.split('\u00a8')
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.left_indent = Cm(std['c_indent'][0])
            pf.first_line_indent = Cm(std['c_indent'][1])
            pf.space_before = Pt(0)
            pf.space_after = Pt(2)
            pf.line_spacing = 1.15
            pf.tab_stops.clear_all()
            for t in std['tabs_2col']:
                pf.tab_stops.add_tab_stop(Cm(t), WD_TAB_ALIGNMENT.LEFT)
            for k, part in enumerate(parts):
                if k > 0:
                    tr = p.add_run('\t')
                    tr.font.name = FN; tr.font.size = FS
                format_para(p, part.strip())
            continue

        # 8. ĐOẠN LỜI GIẢI
        if raw_para.startswith(r'\textbf{Lời giải:}') or raw_para.startswith('Lời giải:'):
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.left_indent = Cm(std['q_indent'][0])
            pf.first_line_indent = Cm(std['q_indent'][1])
            pf.space_before = Pt(3)
            pf.space_after = Pt(2)
            pf.line_spacing = 1.15
            r = p.add_run('Lời giải:\n')
            r.font.name = FN; r.font.size = FS; r.bold = True; r.font.color.rgb = RGBColor(0, 102, 204)
            rem = raw_para.replace(r'\textbf{Lời giải:}', '').replace('Lời giải:', '').strip()
            if rem: format_para(p, rem)
            continue

        # 9. ĐOẠN VĂN THƯỜNG
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.space_before = Pt(1)
        pf.space_after = Pt(2)
        pf.line_spacing = 1.15
        pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        format_para(p, raw_para)

    return doc
