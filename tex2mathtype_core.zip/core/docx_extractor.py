"""
docx_extractor.py - Trích xuất toàn diện nội dung đề thi, công thức & hình vẽ từ file .docx / .doc.
Hỗ trợ chuyển đổi tự động file .doc cũ sang .docx thông qua LibreOffice hoặc Word COM.
Bảo toàn 100% hình ảnh, hình vẽ minh họa trong file Word gốc.
"""

import os
import sys
import re
import tempfile
import subprocess
from docx import Document
from docx.table import Table


def convert_doc_to_docx(doc_path: str, output_dir: str = None) -> str:
    """
    Chuyển đổi file .doc (Word 97-2003) sang .docx.
    Ưu tiên 1: Dùng LibreOffice headless (nhanh, chuẩn).
    Ưu tiên 2: Dùng Microsoft Word COM trên Windows.
    """
    if not output_dir:
        output_dir = tempfile.gettempdir()
    os.makedirs(output_dir, exist_ok=True)
    
    base_name = os.path.splitext(os.path.basename(doc_path))[0]
    target_docx = os.path.join(output_dir, f"{base_name}.docx")
    
    # 1. Thử dùng LibreOffice
    soffice_paths = [
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "soffice"
    ]
    soffice_cmd = None
    for sp in soffice_paths:
        if os.path.exists(sp) or sp == "soffice":
            soffice_cmd = sp
            break
            
    if soffice_cmd:
        try:
            cmd = [soffice_cmd, "--headless", "--convert-to", "docx", doc_path, "--outdir", output_dir]
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=True)
            if os.path.exists(target_docx):
                return target_docx
        except Exception as e:
            print(f"[DOCX_EXTRACTOR] LibreOffice convert error: {e}")

    # 2. Thử dùng Word COM trên Windows
    if sys.platform == "win32":
        try:
            import win32com.client
            word = win32com.client.Dispatch("Word.Application")
            word.Visible = False
            doc = word.Documents.Open(os.path.abspath(doc_path))
            doc.SaveAs2(os.path.abspath(target_docx), FileFormat=16) # 16 = wdFormatXMLDocument (.docx)
            doc.Close()
            word.Quit()
            if os.path.exists(target_docx):
                return target_docx
        except Exception as e:
            print(f"[DOCX_EXTRACTOR] Word COM convert error: {e}")

    raise RuntimeError(f"Không thể chuyển đổi file '{os.path.basename(doc_path)}' sang .docx. Vui lòng cài đặt LibreOffice hoặc Microsoft Word!")


def extract_text_and_questions_from_docx(docx_path: str, media_output_dir: str = None) -> str:
    """
    Đọc toàn bộ văn bản và trích xuất hình vẽ từ file .docx.
    Bảo toàn 100% vị trí các hình vẽ minh họa bằng thẻ \\includegraphics{image_name}.
    Phát hiện các mẫu câu hỏi và phương án A, B, C, D để chuyển thành cấu trúc LaTeX chuẩn.
    """
    doc = Document(docx_path)
    if not media_output_dir:
        media_output_dir = tempfile.mkdtemp(prefix="docx_media_")
    os.makedirs(media_output_dir, exist_ok=True)
    
    img_counter = 0
    extracted_imgs = {} # rId -> saved_filename
    
    def get_or_save_image(rId: str) -> str:
        nonlocal img_counter
        if rId in extracted_imgs:
            return extracted_imgs[rId]
        if rId not in doc.part.rels:
            return ""
        rel = doc.part.rels[rId]
        if "image" not in rel.reltype.lower():
            return ""
        img_part = rel.target_part
        ext = os.path.splitext(rel.target_ref)[1].lower()
        if not ext:
            ext = ".png"
        img_counter += 1
        base_name = f"docx_img_{img_counter:02d}"
        saved_file = base_name + ext
        saved_path = os.path.join(media_output_dir, saved_file)
        with open(saved_path, 'wb') as f:
            f.write(img_part.blob)
            
        # Nếu là WMF hoặc EMF thì tự động chuyển sang PNG để python-docx chèn lại được
        if ext in ['.wmf', '.emf']:
            soffice_paths = [
                r"C:\Program Files\LibreOffice\program\soffice.exe",
                r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
                "soffice"
            ]
            soffice_cmd = None
            for sp in soffice_paths:
                if os.path.exists(sp) or sp == "soffice":
                    soffice_cmd = sp
                    break
            if soffice_cmd:
                try:
                    subprocess.run(
                        [soffice_cmd, "--headless", "--convert-to", "png", saved_path, "--outdir", media_output_dir],
                        capture_output=True, timeout=20
                    )
                    png_name = base_name + ".png"
                    if os.path.exists(os.path.join(media_output_dir, png_name)):
                        saved_file = png_name
                except Exception:
                    pass
        extracted_imgs[rId] = saved_file
        return saved_file

    def process_paragraph_element(p_elem) -> str:
        """Duyệt qua các thẻ con của <w:p> theo đúng thứ tự xuất hiện để lấy text và ảnh."""
        parts = []
        for child in p_elem:
            tag = child.tag.split('}')[-1]
            if tag == 'r':
                # Văn bản trong run
                t_nodes = child.xpath('.//*[local-name()="t"]')
                r_text = "".join(t.text or "" for t in t_nodes)
                if r_text:
                    parts.append(r_text)
                # Ảnh trong run (DrawingML hoặc VML)
                drawings = child.xpath('.//*[local-name()="drawing" or local-name()="pict"]')
                for d in drawings:
                    blips = d.xpath('.//@*[local-name()="embed" or local-name()="id"]')
                    for rId in blips:
                        img_file = get_or_save_image(rId)
                        if img_file:
                            parts.append(f"\n\n\\includegraphics{{{img_file}}}\n\n")
            elif tag in ['drawing', 'pict']:
                blips = child.xpath('.//@*[local-name()="embed" or local-name()="id"]')
                for rId in blips:
                    img_file = get_or_save_image(rId)
                    if img_file:
                        parts.append(f"\n\n\\includegraphics{{{img_file}}}\n\n")
            elif tag == 'hyperlink':
                for sub_r in child.xpath('.//*[local-name()="r"]'):
                    t_nodes = sub_r.xpath('.//*[local-name()="t"]')
                    r_text = "".join(t.text or "" for t in t_nodes)
                    if r_text:
                        parts.append(r_text)
                    drawings = sub_r.xpath('.//*[local-name()="drawing" or local-name()="pict"]')
                    for d in drawings:
                        blips = d.xpath('.//@*[local-name()="embed" or local-name()="id"]')
                        for rId in blips:
                            img_file = get_or_save_image(rId)
                            if img_file:
                                parts.append(f"\n\n\\includegraphics{{{img_file}}}\n\n")
        return "".join(parts).strip()

    all_blocks = []
    body = doc.element.body
    for item in body:
        item_tag = item.tag.split('}')[-1]
        if item_tag == 'p':
            pt = process_paragraph_element(item)
            if pt:
                all_blocks.append(pt)
        elif item_tag == 'tbl':
            tbl = Table(item, doc)
            # Kiểm tra nếu bảng là bảng chứa 4 phương án A, B, C, D
            is_choice_table = False
            if len(tbl.rows) == 1 and len(tbl.columns) == 4:
                c_texts = [process_paragraph_element(tbl.rows[0].cells[ci].paragraphs[0]._element) if tbl.rows[0].cells[ci].paragraphs else "" for ci in range(4)]
                if c_texts[0].startswith("A.") and c_texts[1].startswith("B.") and c_texts[2].startswith("C.") and c_texts[3].startswith("D."):
                    all_blocks.append(f"{c_texts[0]} {c_texts[1]} {c_texts[2]} {c_texts[3]}")
                    is_choice_table = True
            
            if not is_choice_table:
                tbl_lines = []
                for row in tbl.rows:
                    cell_texts = []
                    for cell in row.cells:
                        c_parts = []
                        for cp in cell.paragraphs:
                            cpt = process_paragraph_element(cp._element)
                            if cpt:
                                c_parts.append(cpt)
                        cell_texts.append(" ".join(c_parts).strip())
                    if any(cell_texts):
                        tbl_lines.append(" & ".join(cell_texts) + " \\\\")
                if tbl_lines:
                    num_cols = len(tbl.columns) if tbl.columns else 1
                    tbl_block = f"\\begin{{tabular}}{{'c' * {num_cols}}}\n" + "\n".join(tbl_lines) + "\n\\end{tabular}"
                    all_blocks.append(tbl_block)

    raw_content = "\n\n".join(all_blocks)
    normalized = _restructure_text_to_tex(raw_content)
    return normalized


def _restructure_text_to_tex(text: str) -> str:
    """Chuyển đổi văn bản đề thi thô dạng Word sang định dạng LaTeX chuẩn câu hỏi."""
    lines = text.split('\n')
    output_lines = []
    in_question = False
    
    for line in lines:
        line_str = line.strip()
        if not line_str:
            continue
            
        # Phát hiện bắt đầu câu hỏi mới
        m_q = re.match(r'^(?:Câu|Bài|Ví\s*dụ)\s*(\d+)[\.:]\s*(.*)$', line_str, re.IGNORECASE)
        if m_q:
            if in_question:
                output_lines.append(r"\end{ex}")
            q_num = m_q.group(1)
            q_body = m_q.group(2)
            output_lines.append(f"\\begin{{ex}}\n{q_body}")
            in_question = True
            continue
            
        # Phát hiện 4 phương án trên 1 dòng
        # Ví dụ: A. $x=1$    B. $x=2$    C. $x=3$    D. $x=4$
        m_choices_line = re.search(r'A[\.:]\s*(.*?)\s+B[\.:]\s*(.*?)\s+C[\.:]\s*(.*?)\s+D[\.:]\s*(.*?)$', line_str)
        if m_choices_line:
            c1 = m_choices_line.group(1).strip()
            c2 = m_choices_line.group(2).strip()
            c3 = m_choices_line.group(3).strip()
            c4 = m_choices_line.group(4).strip()
            output_lines.append(f"\\choice\n{{{c1}}}\n{{{c2}}}\n{{{c3}}}\n{{{c4}}}")
            continue

        # Phát hiện Lời giải:
        if re.match(r'^(?:Lời\s*giải|Hướng\s*dẫn\s*giải)[\.:]\s*(.*)$', line_str, re.IGNORECASE):
            m_sol = re.match(r'^(?:Lời\s*giải|Hướng\s*dẫn\s*giải)[\.:]\s*(.*)$', line_str, re.IGNORECASE)
            sol_body = m_sol.group(1).strip()
            output_lines.append(f"\\begin{{loigiai}}\n{sol_body}")
            continue

        output_lines.append(line_str)
        
    if in_question:
        output_lines.append(r"\end{ex}")
        
    return "\n".join(output_lines)
